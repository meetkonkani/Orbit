from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.routes import payments, subscriptions, roles, activity_logs, settings, auth

app = FastAPI(title="SaaS Microservice")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000"],
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth.router, prefix="/api/auth")
app.include_router(payments.router, prefix="/api/payments")
app.include_router(subscriptions.router, prefix="/api/subscriptions")
app.include_router(roles.router, prefix="/api/roles")
app.include_router(activity_logs.router, prefix="/api/activity-logs")
app.include_router(settings.router, prefix="/api/settings")
