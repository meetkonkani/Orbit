from fastapi import APIRouter
from prisma import Prisma

router = APIRouter()
db = Prisma()

@router.get("/")
async def get_activity_logs():
    await db.connect()
    return await db.activitylog.find_many(order={"createdAt": "desc"})
