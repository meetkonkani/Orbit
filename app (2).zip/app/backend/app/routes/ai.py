from fastapi import APIRouter, Depends
from app.core.deps import require_admin
from prisma import Prisma

router = APIRouter()
db = Prisma()

@router.post("/analyze", dependencies=[Depends(require_admin)])
async def analyze_resume(payload: dict):
    text = payload.get("text", "")

    score = min(len(text) / 100, 10)

    await db.activitylog.create(data={
        "adminId": "system",
        "action": "AI_ANALYSIS",
        "entity": "resume",
        "entityId": "auto"
    })

    return {
        "score": round(score, 2),
        "feedback": "Good structure. Add measurable achievements."
    }
