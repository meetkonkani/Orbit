from fastapi import APIRouter, Depends
from prisma import Prisma
from app.core.deps import require_admin

router = APIRouter()
db = Prisma()

@router.get("/", dependencies=[Depends(require_admin)])
async def get_payments():
    await db.connect()
    return await db.payment.find_many()
