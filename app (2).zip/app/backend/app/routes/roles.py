from fastapi import APIRouter
from prisma import Prisma

router = APIRouter()
db = Prisma()

@router.get("/")
async def get_roles():
    await db.connect()
    return await db.role.find_many()
