from fastapi import APIRouter
from prisma import Prisma

router = APIRouter()
db = Prisma()

@router.get("/")
async def get_settings():
    await db.connect()
    return await db.appsetting.find_many()
