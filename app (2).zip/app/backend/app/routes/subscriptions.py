from fastapi import APIRouter
from prisma import Prisma

router = APIRouter()
db = Prisma()

@router.get("/")
async def get_subscriptions():
    await db.connect()
    return await db.subscription.find_many()
