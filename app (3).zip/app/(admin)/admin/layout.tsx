import { auth } from "@/app/auth";
import { redirect } from "next/navigation";
import Sidebar from "@/app/components/admin/Sidebar";
import CustomCursor from "@/app/components/CustomCursor";

export default async function AdminLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const session = await auth();

  if (!session || session.user.role !== "ADMIN") {
    redirect("/auth/login?callbackUrl=/admin");
  }

  return (
    <div className="flex min-h-screen bg-[#0a0a0a] text-white">
      {/* 1. Sidebar is likely 'fixed' */}
      <Sidebar /> 
      
      <CustomCursor />

      {/* 2. Added ml-64 to prevent content from hiding behind the sidebar */}
      {/* Remove ml-64 and use flex-1 */}
<main className="flex-1 min-w-0">
  <div className="p-4 md:p-8">
    {children}
  </div>
</main>
    </div>
  );
}