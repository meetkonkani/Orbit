import { prisma } from "@/app/lib/prisma";
import Link from "next/link";
import { deleteOrder } from "@/app/actions/admin";

type AdminOrder = {
  id: string;
  total: number;
  status: string;
  createdAt: Date;
  user?: { email?: string | null } | null;
  items: { id: string }[];
};

export default async function AdminOrdersPage() {
  const rawOrders = (await prisma.order.findMany({
    include: { user: true, items: true },
    orderBy: { createdAt: "desc" },
  })) as unknown as AdminOrder[];

  const orders: AdminOrder[] = rawOrders.map((o) => ({
    id: o.id,
    total: Number(o.total),
    status: o.status,
    createdAt: o.createdAt,
    user: o.user,
    items: o.items,
  }));

  return (
    <div className="p-8 text-white">
      <h1 className="text-3xl font-bold uppercase mb-8">Order Management</h1>

      <table className="w-full bg-white/5 rounded-xl overflow-hidden">
        <thead className="bg-white/10 text-xs uppercase">
          <tr>
            <th className="p-4">ID</th>
            <th className="p-4">Customer</th>
            <th className="p-4">Items</th>
            <th className="p-4">Total</th>
            <th className="p-4">Status</th>
            <th className="p-4 text-right">Actions</th>
          </tr>
        </thead>

        <tbody className="text-xs">
          {orders.map((order) => (
            <tr key={order.id} className="border-t border-white/10">
              <td className="p-4">#{order.id.slice(-6)}</td>
              <td className="p-4">{order.user?.email || "Guest"}</td>
              <td className="p-4">{order.items.length}</td>
              <td className="p-4 text-green-400">₹{order.total.toFixed(2)}</td>
              <td className="p-4">{order.status}</td>
              <td className="p-4 text-right flex gap-2 justify-end">
                <Link
                  href={`/admin/orders/${order.id}`}
                  className="px-3 py-1 bg-white/10 rounded"
                >
                  View
                </Link>

                <form
                  action={async () => {
                    "use server";
                    await deleteOrder(order.id);
                  }}
                >
                  <button className="px-3 py-1 bg-red-500/30 text-red-300 rounded">
                    Delete
                  </button>
                </form>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
