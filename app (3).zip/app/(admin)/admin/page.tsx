"use client";

import { useEffect, useState } from "react";

type StatusGroup = {
  status: string;
  _count: { status: number };
};

type Analytics = {
  totalOrders: number;
  totalRevenue: number;
  statusGroup: StatusGroup[];
};

export default function AdminDashboard() {
  const [data, setData] = useState<Analytics | null>(null);
  const [error, setError] = useState("");

  useEffect(() => {
    const token = localStorage.getItem("saas_token");

    if (!token) {
      setError("Admin not authenticated");
      return;
    }

    fetch("http://localhost:8000/api/analytics/orders", {
      headers: { Authorization: `Bearer ${token}` },
    })
      .then(async res => {
        if (!res.ok) {
          const txt = await res.text();
          throw new Error(txt || "Unauthorized");
        }
        return res.json();
      })
      .then(json => {
        // 💥 SAFETY NORMALIZATION
        setData({
          totalOrders: Number(json.totalOrders || 0),
          totalRevenue: Number(json.totalRevenue || 0),
          statusGroup: Array.isArray(json.statusGroup) ? json.statusGroup : [],
        });
      })
      .catch(() => setError("Admin authorization failed"));
  }, []);

  if (error) return <p className="p-8 text-red-400">{error}</p>;
  if (!data) return <p className="p-8 text-white">Loading...</p>;

  return (
    <div className="p-8 text-white">
      <h1 className="text-3xl font-bold mb-8">Analytics Hub</h1>

      <div className="grid grid-cols-2 gap-6 mb-10">
        <div className="bg-white/10 p-4 rounded">
          <p className="text-xs opacity-60">Total Orders</p>
          <p className="text-2xl font-bold">{data.totalOrders}</p>
        </div>

        <div className="bg-white/10 p-4 rounded">
          <p className="text-xs opacity-60">Total Revenue</p>
          <p className="text-2xl font-bold">₹{data.totalRevenue}</p>
        </div>
      </div>

      {data.statusGroup.length === 0 && (
        <p className="text-xs text-neutral-400">No order activity yet</p>
      )}

      {data.statusGroup.map(group => (
        <div key={group.status} className="mb-4">
          <div className="flex justify-between text-xs">
            <span>{group.status}</span>
            <span>{group._count.status}</span>
          </div>

          <div className="h-1 bg-white/20">
            <div
              className="h-full bg-white"
              style={{
                width: data.totalOrders
                  ? `${(group._count.status / data.totalOrders) * 100}%`
                  : "0%",
              }}
            />
          </div>
        </div>
      ))}
    </div>
  );
}
