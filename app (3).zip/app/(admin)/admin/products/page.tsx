import { prisma } from "@/app/lib/prisma";
import { deleteProduct } from "@/app/actions/admin";
import Image from "next/image";
import Link from "next/link";

interface Product {
  id: string;
  title: string;
  description: string;
  price: number;
  images: string[];
  category: string;
  stock: number;
  createdAt: Date;
  updatedAt: Date;
}

export default async function AdminProductsPage() {
  const products = await prisma.product.findMany({
    orderBy: { createdAt: "desc" },
  }) as Product[];

  return (
    <div className="p-8 text-white">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold">Products</h1>
          <p className="text-neutral-400 mt-1">Manage your shop inventory</p>
        </div>
        <Link 
          href="/admin/products/new" 
          className="bg-white text-black px-6 py-2 rounded-full font-medium hover:bg-neutral-200 transition"
        >
          + Add Product
        </Link>
      </div>

      <div className="bg-white/5 border border-white/10 rounded-2xl overflow-hidden backdrop-blur-sm">
        <table className="w-full text-left">
          <thead className="bg-white/5 border-b border-white/10">
            <tr>
              <th className="p-4 text-sm font-semibold text-neutral-400">Product</th>
              <th className="p-4 text-sm font-semibold text-neutral-400">Category</th>
              <th className="p-4 text-sm font-semibold text-neutral-400">Price</th>
              <th className="p-4 text-sm font-semibold text-neutral-400">Stock</th>
              <th className="p-4 text-sm font-semibold text-neutral-400 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-white/5">
            {products.map((product) => (
              <tr key={product.id} className="hover:bg-white/5 transition">
                <td className="p-4 flex items-center gap-3">
                  <div className="w-12 h-12 relative bg-neutral-800 rounded-lg overflow-hidden border border-white/10">
                    {product.images?.[0] && (
                      <Image 
  src={product.images[0]} 
  alt={product.title} 
  fill 
  unoptimized // Add this to keep the admin list fast
  className="object-cover"
  sizes="48px"
/>
                    )}
                  </div>
                  <span className="font-medium">{product.title}</span>
                </td>
                <td className="p-4 text-sm text-neutral-400">{product.category}</td>
                <td className="p-4 text-sm font-bold text-green-400">
                  ${(product.price ).toFixed(2)}
                </td>
                <td className="p-4 text-sm">
                  <span className={product.stock < 5 ? "text-red-400 font-bold" : "text-neutral-300"}>
                    {product.stock}
                  </span>
                </td>
                <td className="p-4 text-right space-x-2">
                  <Link 
                    href={`/admin/products/${product.id}`}
                    className="text-xs bg-white/10 px-3 py-1.5 rounded-md hover:bg-white/20 transition"
                  >
                    Edit
                  </Link>
                  <form action={async () => {
                    "use server";
                    await deleteProduct(product.id);
                  }} className="inline">
                    <button 
                      type="submit"
                      className="text-xs text-red-400 bg-red-400/10 px-3 py-1.5 rounded-md hover:bg-red-400/20 transition"
                    >
                      Delete
                    </button>
                  </form>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {products.length === 0 && (
          <div className="p-20 text-center text-neutral-500">
            No products found. Click "+ Add Product" to get started.
          </div>
        )}
      </div>
    </div>
  );
}