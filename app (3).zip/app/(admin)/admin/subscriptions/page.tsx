"use client";
import { useEffect, useState } from "react";

export default function Subscriptions() {
  const [plans, setPlans] = useState<any[]>([]);

  useEffect(() => {
    const token = localStorage.getItem("saas_token");
    if (!token) return;

    fetch("http://localhost:8000/api/subscriptions", {
      headers: { Authorization: `Bearer ${token}` },
    })
      .then(r => r.json())
      .then(setPlans);
  }, []);

  return (
    <div className="p-10 text-white">
      <h1 className="text-2xl mb-6">Subscription Plans</h1>

      {plans?.map(p => (
        <div key={p.id} className="bg-white/10 p-4 mb-3 rounded">
          <p className="font-bold">{p.name}</p>
          <p>₹{p.price} – {p.limit} AI uses</p>
        </div>
      ))}
    </div>
  );
}
