import { prisma } from "@/app/lib/prisma"; 
import { toggleUserRole } from "@/app/actions/admin";

interface User {
  id: string;
  name: string | null;
  email: string | null;
  role: string;
  createdAt: Date;
  updatedAt: Date;
  image?: string | null;
}

export default async function AdminUsersPage() {
  
  const users = await prisma.user.findMany({
    orderBy: { createdAt: "desc" },
  }) as User[]; // <-- Add this


  return (
    <div className="p-8 text-white">
      <div className="mb-8">
        <h1 className="text-3xl font-bold">User Management</h1>
        <p className="text-neutral-400 mt-1">Manage permissions and roles</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {users.map((user) => (
          <div 
            key={user.id} 
            className="p-6 bg-white/5 border border-white/10 rounded-2xl backdrop-blur-sm flex flex-col justify-between"
          >
            <div className="mb-6">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-neutral-700 to-neutral-500 flex items-center justify-center text-sm font-bold">
                  {user.name?.charAt(0) || "U"}
                </div>
                <div>
                  <p className="font-bold">{user.name || "Anonymous User"}</p>
                  <p className="text-xs text-neutral-500">{user.email}</p>
                </div>
              </div>
              
              <div className="flex items-center gap-2">
                <span className="text-[10px] text-neutral-400 uppercase tracking-widest font-semibold">Current Role:</span>
                <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold uppercase ${
                  user.role === 'ADMIN' ? 'bg-purple-500/20 text-purple-400 border border-purple-500/20' : 'bg-blue-500/20 text-blue-400 border border-blue-500/20'
                }`}>
                  {user.role}
                </span>
              </div>
            </div>

            <form action={async () => {
              "use server";
              await toggleUserRole(user.id, user.role);
            }}>
              <button className="w-full text-xs font-bold py-2.5 rounded-lg border border-white/10 hover:bg-white hover:text-black transition duration-300">
                {user.role === 'ADMIN' ? "Demote to User" : "Promote to Admin"}
              </button>
            </form>
          </div>
        ))}
      </div>
    </div>
  );
}