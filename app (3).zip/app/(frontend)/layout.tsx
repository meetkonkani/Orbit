// app/(frontend)/layout.tsx
import Navbar from "@/app/components/Navbar";
import Footer from "@/app/components/Footer";
import CartUI from "@/app/components/CartUI";

export default function FrontendLayout({ children }: { children: React.ReactNode }) {
  return (
    <>
      <Navbar />
      <CartUI />
      {children}
      <Footer />
    </>
  );
}