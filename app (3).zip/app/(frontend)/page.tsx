"use client";

import React, { useState } from "react";
import { motion } from "framer-motion";
import { useRouter } from "next/navigation";

import ParticleSphere from "../components/ParticleSphere";
import MagneticButton from "../components/MagneticButton";
import ContactModal from "../components/ContactModal";
import Preloader from "../components/Preloader";
import HyperText from "../components/HyperText";
import Lookbook from "../components/LookBook";
import Gallery from "../components/Gallery";

function Marquee() {
  return (
    <div className="relative z-20 flex w-full overflow-hidden bg-white py-4 my-20">
      <div className="animate-marquee whitespace-nowrap text-4xl font-black text-black uppercase tracking-tighter">
        {[...Array(4)].map((_, i) => (
          <React.Fragment key={i}>
            <span className="mx-8">Limited Drop</span>
            <span className="mx-8 text-neutral-400">///</span>
            <span className="mx-8">Season 04</span>
            <span className="mx-8 text-neutral-400">///</span>
            <span className="mx-8">Worldwide Shipping</span>
            <span className="mx-8 text-neutral-400">///</span>
            <span className="mx-8">Cyber-Engineered Apparel</span>
            <span className="mx-8 text-neutral-400">///</span>
          </React.Fragment>
        ))}
      </div>
    </div>
  );
}

export default function Homepage() {
  const router = useRouter();
  const [isModalOpen, setIsModalOpen] = useState(false);

  const manifesto = [
    "TRADITION IS OFFLINE.",
    "UPGRADE YOUR AVATAR.",
    "DESIGNED IN THE VOID.",
    "BUILT FOR THE RELENTLESS.",
    "DEPLOYED GLOBALLY.",
  ];

  return (
    <main className="w-full min-h-screen bg-black relative selection:bg-white selection:text-black overflow-x-hidden">

      <div className="relative z-[60]">
        <Preloader />
        <ContactModal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} />
      </div>

      <div className="fixed inset-0 z-0">
        <ParticleSphere />
      </div>

      <div className="relative z-10 flex flex-col gap-10">

        {/* HERO */}
        <section className="h-screen flex flex-col items-center justify-center text-center">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 1 }}
          >
            <p className="mb-6 text-xs font-mono tracking-[0.5em] text-neutral-500 uppercase">
              DROP SEASON 04
            </p>

            <h1 className="text-7xl md:text-9xl font-black tracking-tighter mb-6">
              <HyperText text="ORBIT." />
            </h1>

            <p className="text-xl md:text-2xl text-neutral-400 max-w-xl mx-auto mb-10">
              Not clothing. <span className="text-white">Identity engineering.</span>
            </p>

            <div onClick={() => router.push("/shop")} className="cursor-pointer">
              <MagneticButton>Enter The Drop</MagneticButton>
            </div>
          </motion.div>
        </section>

        <Marquee />

        {/* LOOKBOOK */}
        <Lookbook />

        {/* MANIFESTO */}
        <section className="min-h-screen flex flex-col justify-center px-6 md:px-20">
          <div className="max-w-7xl mx-auto">
            {manifesto.map((line, i) => (
              <motion.h2
                key={i}
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1 }}
                className="text-4xl md:text-7xl font-black tracking-tighter uppercase leading-none mb-4"
              >
                {line}
              </motion.h2>
            ))}
          </div>
        </section>

        {/* GALLERY */}
        <Gallery />

        {/* CTA */}
        <section className="h-[60vh] flex flex-col items-center justify-center text-center">
          <h2 className="text-4xl font-black mb-6">
            Join the Inner Circle.
          </h2>
          <p className="text-neutral-500 text-sm max-w-md mb-10">
            Exclusive early access. No spam. No mass-drops. Only precision.
          </p>
          <div onClick={() => setIsModalOpen(true)} className="cursor-pointer">
            <MagneticButton>Get Access</MagneticButton>
          </div>
        </section>

      </div>
    </main>
  );
}
