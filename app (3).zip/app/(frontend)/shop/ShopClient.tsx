"use client";

import { useState, useMemo, useEffect } from "react";
import Link from "next/link";
import { motion, AnimatePresence } from "framer-motion";
import { Search, SlidersHorizontal, ChevronDown } from "lucide-react";

const CATEGORIES = ["ALL", "HOODIES", "T-SHIRTS", "ACCESSORIES"];
const SORT_OPTIONS = [
  { label: "Newest", value: "newest" },
  { label: "Price: Low to High", value: "low" },
  { label: "Price: High to Low", value: "high" },
];

export default function ShopClient({ initialProducts, initialCategory }: any) {
  const [activeCategory, setActiveCategory] = useState(initialCategory);
  const [searchQuery, setSearchQuery] = useState("");
  const [sortBy, setSortBy] = useState("newest");

  useEffect(() => {
    if (initialCategory) setActiveCategory(initialCategory.toUpperCase());
  }, [initialCategory]);

 const filteredAndSortedProducts = useMemo(() => {
    // 1. First, filter the items
    let filtered = initialProducts.filter((p: any) => {
      const matchesCategory = 
        activeCategory === "ALL" || 
        p.category.toUpperCase() === activeCategory.toUpperCase();
      const matchesSearch = p.title.toLowerCase().includes(searchQuery.toLowerCase());
      return matchesCategory && matchesSearch;
    });

    // 2. Create a NEW copy of the array before sorting [...filtered]
    // 3. Force the price to be a Number to stop the red line
    if (sortBy === "low") {
      filtered = [...filtered].sort((a, b) => Number(a.price) - Number(b.price));
    } else if (sortBy === "high") {
      filtered = [...filtered].sort((a, b) => Number(b.price) - Number(a.price));
    }
    
    return filtered;
  }, [activeCategory, searchQuery, sortBy, initialProducts]); 

  return (
    <main className="min-h-screen bg-black text-white pt-32 px-6 md:px-16 pb-20">
      
      {/* --- PREMIUM NAVIGATION & FILTERS --- */}
      <div className="flex flex-col gap-8 mb-12">
        <div className="flex justify-between items-end">
          <div>
            <h1 className="text-5xl font-bold tracking-tighter uppercase mb-2">Shop All</h1>
            <p className="text-neutral-500 text-sm font-medium">
              Showing {filteredAndSortedProducts.length} items
            </p>
          </div>
          
          <div className="hidden md:flex items-center gap-4">
            <div className="relative group">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-neutral-500 group-focus-within:text-white transition-colors" size={16} />
              <input 
                type="text" 
                placeholder="Search products..."
                className="bg-neutral-900 border border-transparent focus:border-white/20 rounded-lg pl-10 pr-4 py-2 text-sm outline-none transition-all w-64"
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
          </div>
        </div>

        {/* Filter Bar */}
        <div className="flex flex-wrap items-center justify-between border-y border-white/10 py-4">
          <div className="flex gap-2 overflow-x-auto no-scrollbar">
            {CATEGORIES.map((cat) => (
              <button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className={`px-6 py-2 rounded-full text-xs font-bold uppercase tracking-widest transition-all
                  ${activeCategory === cat 
                    ? "bg-white text-black" 
                    : "bg-neutral-900 text-neutral-400 hover:bg-neutral-800"}`}
              >
                {cat}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-6 mt-4 md:mt-0">
            <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-neutral-400">
              <SlidersHorizontal size={14} />
              <span>Sort By:</span>
              <select 
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value)}
                className="bg-transparent text-white outline-none cursor-pointer hover:text-neutral-300"
              >
                {SORT_OPTIONS.map(opt => <option key={opt.value} value={opt.value} className="bg-black">{opt.label}</option>)}
              </select>
            </div>
          </div>
        </div>
      </div>

      {/* --- PRODUCT GRID --- */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-x-8 gap-y-16">
        <AnimatePresence mode="popLayout">
          {filteredAndSortedProducts.map((product: any) => (
            <motion.div
              key={product.id}
              layout
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.3 }}
            >
              <Link href={`/products/${product.id}`} className="group flex flex-col gap-4">
                {/* Image Aspect Ratio 1:1 or 4:5 is best for modern fashion */}
                <div className="relative aspect-[4/5] overflow-hidden bg-neutral-900 rounded-2xl transition-all">
                  <img 
                    src={product.images?.[0]} 
                    alt={product.title} 
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                  />
                  
                  {/* Quick Add Label */}
                  <div className="absolute bottom-4 left-4 right-4 translate-y-4 opacity-0 group-hover:translate-y-0 group-hover:opacity-100 transition-all duration-300">
                    <button className="w-full bg-white text-black py-3 rounded-xl text-xs font-black uppercase tracking-widest shadow-2xl">
                      Quick View
                    </button>
                  </div>
                </div>

                <div className="space-y-1">
                  <div className="flex justify-between items-start">
                    <h3 className="text-base font-bold text-neutral-200 group-hover:text-white transition-colors">
                      {product.title}
                    </h3>
                  </div>
                  <div className="flex justify-between items-center text-sm">
                    <p className="text-neutral-500">{product.category}</p>
                    <p className="font-bold text-white">${Number(product.price).toFixed(2)}</p>
                  </div>
                </div>
              </Link>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>

      {filteredAndSortedProducts.length === 0 && (
        <div className="py-40 text-center">
          <p className="text-neutral-500 uppercase tracking-widest text-sm">No products found in this category.</p>
        </div>
      )}
    </main>
  );
}