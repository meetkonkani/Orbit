import ShopPage from "../page";

export default function CategoryPage({
  params,
}: {
  params: { category: string };
}) {
  return <ShopPage searchParams={{ category: decodeURIComponent(params.category).toUpperCase() }} />;
}
