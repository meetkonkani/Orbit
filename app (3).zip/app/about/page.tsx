"use client";

import React from "react";
import { motion } from "framer-motion";
import Link from "next/link";
import CustomCursor from "../components/CustomCursor";
import Footer from "../components/Footer";
import FloatingDock from "../components/FloatingDock";
import { useRouter } from "next/navigation";
import router from "next/router";

export default function AboutPage() {
  return (
    <main className="min-h-screen w-full bg-black text-white selection:bg-white selection:text-black">
      <CustomCursor />
      <div className="relative z-[999]">
        <FloatingDock onCartClick={() => router.push('/cart')} />
      </div>
      

      {/* 1. HEADER SECTION */}
      <section className="pt-32 pb-20 px-6 md:px-12 border-b border-white/10">
        <div className="max-w-6xl mx-auto">
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-[10vw] leading-[0.8] font-black tracking-tighter uppercase mb-12"
          >
            The Signal
          </motion.h1>

          <div className="flex flex-col md:flex-row gap-12 md:gap-32">
            <div className="md:w-1/3">
              <p className="font-mono text-sm text-neutral-500 uppercase tracking-widest mb-2">/// Mission Protocol</p>
              <p className="text-xl font-medium leading-relaxed">
                We do not design clothes. We engineer survival gear for the digital apocalypse.
              </p>
            </div>
            <div className="md:w-1/3">
               <p className="font-mono text-sm text-neutral-500 uppercase tracking-widest mb-2">/// Origin</p>
               <p className="text-neutral-400 leading-relaxed">
                 Founded in Sector 7G (Tokyo) in 2024, Orbit Studios emerged as a response to fast fashion. We utilize recycled carbon polymers and smart-fabrics to create garments that last a lifetime.
               </p>
            </div>
          </div>
        </div>
      </section>

                 {/* DATA GRID */}
        <section className="py-20 border-t border-white/10">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-10 px-6 md:px-20 max-w-7xl mx-auto">
            <div className="space-y-10">
              <motion.p 
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.8 }}
                className="text-2xl md:text-4xl leading-tight font-light text-neutral-400"
              >
                Traditional fashion is static. <span className="text-white">Orbit is dynamic.</span> We utilize 
                radar-absorbent materials, aerogel insulation, and modular attachment systems.
              </motion.p>
            </div>
            <div className="grid grid-cols-2 gap-4 font-mono text-xs md:text-sm text-neutral-500">
              {[
                { title: "ESTABLISHED", val: "2077" },
                { title: "HQ LOCATION", val: "NEO-TOKYO" },
                { title: "MATERIALS", val: "100% SYNTHETIC" },
                { title: "GLOBAL SHIPPING", val: "TRUE" }
              ].map((item, index) => (
                <motion.div 
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: 0.2 + (index * 0.1) }}
                  className="border border-white/10 p-6 flex flex-col justify-between h-40 hover:bg-white/5 transition-colors"
                >
                  <span>{item.title}</span>
                  <span className="text-white text-xl">{item.val}</span>
                </motion.div>
              ))}
            </div>
          </div>
        </section>


      {/* 2. BIG IMAGE / PARALLAX EFFECT */}
      <div className="w-full h-[60vh] overflow-hidden relative">
        <div 
           className="absolute inset-0 bg-cover bg-center grayscale hover:grayscale-0 transition-all duration-700"
           style={{ backgroundImage: 'url("https://images.unsplash.com/photo-1523398002811-999ca8dec234?q=80&w=2000&auto=format&fit=crop")' }}
        />
        <div className="absolute inset-0 bg-black/20" />
      </div>

      {/* 3. STATS GRID */}
      <section className="py-20 px-6 md:px-12">
        <div className="max-w-6xl mx-auto grid grid-cols-2 md:grid-cols-4 gap-8">
            {[
                { label: "Collections", value: "04" },
                { label: "Global HQs", value: "03" },
                { label: "Sustainability", value: "100%" },
                { label: "Cybernetics", value: "Active" },
            ].map((stat, i) => (
                <div key={i} className="border-l border-white/20 pl-6">
                    <h3 className="text-4xl md:text-6xl font-black mb-2">{stat.value}</h3>
                    <p className="font-mono text-xs text-neutral-500 uppercase">{stat.label}</p>
                </div>
            ))}
        </div>
      </section>
        
      {/* 4. RETURN CTA */}
      <div className="py-20 text-center">
         <Link href="/">
            <button className="px-8 py-4 border border-white/20 rounded-full hover:bg-white hover:text-black transition-all uppercase tracking-widest text-sm font-bold">
                ← Return to Base
            </button>
         </Link>
      </div>
    </main>
  );
}