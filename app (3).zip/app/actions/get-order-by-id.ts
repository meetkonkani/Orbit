"use server";

import { prisma } from "@/app/lib/prisma";
import { auth } from "@/app/auth";

// Your existing function stays the same
export async function getOrderById(orderId: string) {
  const session = await auth();

  if (!session?.user?.email) {
    return { error: "Unauthorized" };
  }

  const user = await prisma.user.findUnique({
    where: { email: session.user.email },
  });

  if (!user) {
    return { error: "User not found" };
  }

  const order = await prisma.order.findFirst({
    where: {
      id: orderId,
      userId: user.id, // 🔒 user can only see own orders
    },
    include: {
      items: true,
    },
  });

  if (!order) {
    return { error: "Order not found" };
  }

  return { order };  // ✅ This is what your component expects
}

// ✅ ADD THIS NEW FUNCTION for the dashboard
export async function getUserOrders() {
  const session = await auth();

  if (!session?.user?.email) {
    return { error: "Unauthorized" };
  }

  const user = await prisma.user.findUnique({
    where: { email: session.user.email },
  });

  if (!user) {
    return { error: "User not found" };
  }

  // Fetch ALL orders for this user
  const orders = await prisma.order.findMany({
    where: {
      userId: user.id, // Get all orders for this user
    },
    orderBy: {
      createdAt: 'desc', // Newest first
    },
    include: {
      items: true,
    },
  });

  return { orders }; // Return { orders } not { order }
}