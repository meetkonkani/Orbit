"use server";

import { prisma } from "@/app/lib/prisma";
import { auth } from "@/app/auth";

export async function getUserOrders() {
  const session = await auth();

  if (!session?.user?.email) {
    return { error: "AUTH_REQUIRED" };
  }

  try {
    const orders = await prisma.order.findMany({
      where: {
        user: { email: session.user.email },
      },
      include: {
        items: true,
      },
      orderBy: {
        createdAt: "desc",
      },
    });

    return { success: true, orders };
  } catch (error) {
    console.error("FETCH_ORDERS_ERROR:", error);
    return { error: "FAILED_TO_LOAD_ARCHIVES" };
  }
}