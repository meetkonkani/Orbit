import { NextResponse } from "next/server";
import Razorpay from "razorpay";

const razorpay = new Razorpay({
  key_id: process.env.RAZORPAY_KEY_ID!,
  key_secret: process.env.RAZORPAY_KEY_SECRET!,
});

export async function POST(req: Request) {
  try {
    const { cart } = await req.json();

    if (!cart || cart.length === 0) {
      return NextResponse.json({ error: "CART_EMPTY" }, { status: 400 });
    }

    const total = cart.reduce(
      (sum: number, item: any) => sum + item.price * item.quantity,
      0
    );

    const order = await razorpay.orders.create({
      amount: Math.round(total * 100),
      currency: "INR",
    });

    return NextResponse.json(order);
  } catch (err) {
    console.error("RAZORPAY_ORDER_ERROR:", err);
    return NextResponse.json({ error: "RAZORPAY_DOWN" }, { status: 500 });
  }
}
