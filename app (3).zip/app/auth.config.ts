// app/auth.config.ts
import type { NextAuthConfig } from "next-auth";

export const authConfig = {
  pages: {
    signIn: "/auth/login",
  },
  callbacks: {
    authorized({ auth, request: { nextUrl } }) {
      // 1. ALWAYS allow API auth routes to prevent the "Unexpected token <" error
      if (nextUrl.pathname.startsWith("/api/auth")) return true;

      const isLoggedIn = !!auth?.user;
      const isAdmin = auth?.user?.role === "ADMIN";

      const isAdminPage = nextUrl.pathname.startsWith("/admin");
      const isDashboardPage = nextUrl.pathname.startsWith("/dashboard");
      const isAuthPage = nextUrl.pathname.startsWith("/auth");

      // 2. Protect Admin Section
      if (isAdminPage) {
        if (isLoggedIn && isAdmin) return true;
        return false; // Redirects to login
      }

      // 3. Protect User Dashboard
      if (isDashboardPage) {
        if (isLoggedIn) return true;
        return false; // Redirects to login
      }

      // 4. If user is logged in, don't let them see Login/Signup pages
      if (isAuthPage && isLoggedIn) {
        return Response.redirect(new URL("/dashboard", nextUrl));
      }

      return true; // All other pages (Shop, Home, About) are public
    },
  },
  providers: [], // Add providers in auth.ts, not here
} satisfies NextAuthConfig;