from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.db.prisma import db

from app.routes import (
    payments,
    subscriptions,
    activity_logs,
    analytics,
    auth,
)

app = FastAPI(title="SaaS Microservice")

@app.on_event("startup")
async def startup():
    await db.connect()

@app.on_event("shutdown")
async def shutdown():
    await db.disconnect()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000"],
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth.router, prefix="/api/auth")
app.include_router(payments.router, prefix="/api/payments")
app.include_router(subscriptions.router, prefix="/api/subscriptions")
app.include_router(activity_logs.router, prefix="/api/activity-logs")
app.include_router(analytics.router, prefix="/api/analytics")
