from fastapi import APIRouter, Depends
from app.core.deps import require_admin
from app.db.prisma import db

router = APIRouter()

@router.get("/", dependencies=[Depends(require_admin)])
async def get_logs():
    return await db.activitylog.find_many(order={"createdAt": "desc"})
