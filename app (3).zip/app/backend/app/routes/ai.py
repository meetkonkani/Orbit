from fastapi import APIRouter, Depends
from app.core.deps import require_admin
from app.db.prisma import db   # 👈 import global instance

router = APIRouter()

@router.post("/analyze", dependencies=[Depends(require_admin)])
async def analyze_resume(payload: dict):

    usage = await db.activitylog.count(
        where={"action": "AI_ANALYSIS"}
    )

    if usage >= 10:
        return {"error": "USAGE_LIMIT_EXCEEDED"}

    await db.activitylog.create(data={
        "action": "AI_ANALYSIS",
        "userId": "system"
    })

    return {
        "score": min(len(payload.get("text", "")) / 100, 10),
        "feedback": "Resume quality looks good."
    }
