from fastapi import APIRouter, Depends
from app.core.deps import require_admin
from app.db.prisma import db

router = APIRouter()

@router.get("/orders", dependencies=[Depends(require_admin)])
async def get_order_analytics():

    payments = await db.payment.find_many()

    total_orders = len(payments)
    total_revenue = sum(p.amount for p in payments if p.status == "PAID")

    status_map = {}
    for p in payments:
        status_map[p.status] = status_map.get(p.status, 0) + 1

    return {
        "totalOrders": total_orders,
        "totalRevenue": total_revenue,
        "statusGroup": [
            {"status": k, "_count": {"status": v}}
            for k, v in status_map.items()
        ]
    }
