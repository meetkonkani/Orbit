from fastapi import APIRouter
from app.db.prisma import db

router = APIRouter()

@router.post("/order-created")
async def order_created(payload: dict):

    await db.activitylog.create(data={
        "userId": payload.get("userId", "system"),
        "action": f"ORDER_CREATED:{payload.get('orderId')}"
    })

    return {"status": "logged"}
