from fastapi import APIRouter, Depends
from app.core.deps import require_admin
from app.db.prisma import db

router = APIRouter()

@router.get("/", dependencies=[Depends(require_admin)])
async def get_payments():
    return await db.payment.find_many()
