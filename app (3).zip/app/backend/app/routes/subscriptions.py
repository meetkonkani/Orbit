from fastapi import APIRouter, Depends
from app.core.deps import require_admin
from app.db.prisma import db

router = APIRouter()

@router.post("/create", dependencies=[Depends(require_admin)])
async def create_plan(payload: dict):
    return await db.subscription.create(data={
        "name": payload["name"],
        "price": payload["price"],
        "limit": payload["limit"],
    })

@router.get("/")
async def get_plans():
    return await db.subscription.find_many()
