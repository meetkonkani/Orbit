"use client";

import React from "react";
import { motion } from "framer-motion";
import CustomCursor from "../components/CustomCursor";
import Footer from "../components/Footer";
import FloatingDock from "../components/FloatingDock";
import { useRouter } from "next/navigation";

const visualData = [
  { id: 1, src: "https://images.unsplash.com/photo-1506629082955-511b1aa562c8?q=80&w=800", size: "tall", label: "PHASE_01 // THERMAL" },
  { id: 2, src: "https://images.unsplash.com/photo-1517841905240-472988babdf9?q=80&w=800", size: "square", label: "PHASE_02 // KINETIC" },
  { id: 3, src: "https://images.unsplash.com/photo-1529139513402-e209979821ed?q=80&w=800", size: "wide", label: "PHASE_03 // STEALTH" },
  { id: 4, src: "https://images.unsplash.com/photo-1539109136881-3be0616acf4b?q=80&w=800", size: "tall", label: "PHASE_04 // URBAN" },
];

export default function CampaignPage() {
  return (
    <main className="min-h-screen bg-black text-white selection:bg-white selection:text-black">
      <CustomCursor />
      <FloatingDock onCartClick={function (): void {
              throw new Error("Function not implemented.");
          } } />

      {/* HERO SECTION */}
      <section className="pt-40 pb-20 px-6 md:px-20">
        <div className="max-w-7xl mx-auto border-b border-white/10 pb-10">
          <motion.p 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="font-mono text-[10px] text-green-500 tracking-[0.5em] mb-4"
          >
            /// ARCHIVE_STREAM_S04
          </motion.p>
          <motion.h1 
            initial={{ y: 50, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            className="text-6xl md:text-[12vw] font-black uppercase leading-[0.8] tracking-tighter"
          >
            TERRA<br/>FORMA
          </motion.h1>
        </div>
      </section>

      {/* BENTO CAMPAIGN GRID */}
      <section className="px-6 md:px-20 pb-40">
        <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-12 gap-6 md:gap-10">
          {visualData.map((item, i) => (
            <motion.div
              key={item.id}
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
              viewport={{ once: true }}
              className={`relative group overflow-hidden border border-white/5 
                ${item.size === "tall" ? "md:col-span-5 h-[70vh]" : ""}
                ${item.size === "square" ? "md:col-span-7 h-[50vh]" : ""}
                ${item.size === "wide" ? "md:col-span-12 h-[60vh]" : ""}
              `}
            >
              <img 
                src={item.src} 
                className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-1000 group-hover:scale-105"
                alt={item.label}
              />
              <div className="absolute inset-0 bg-black/20 group-hover:bg-transparent transition-colors" />
              <div className="absolute bottom-6 left-6 flex flex-col">
                <span className="font-mono text-[10px] text-white/60 mb-1">{item.label}</span>
                <div className="h-px w-0 group-hover:w-full bg-white transition-all duration-500" />
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* CALL TO ACTION */}
      <section className="py-40 bg-white text-black text-center">
         <h2 className="text-4xl md:text-7xl font-black uppercase tracking-tighter mb-10">
            End Transmission.
         </h2>
         <button className="px-10 py-4 border-2 border-black font-bold uppercase hover:bg-black hover:text-white transition-all">
            Enter the store
         </button>
      </section>

    </main>
  );
}