"use client";

import { motion } from "framer-motion";

export default function BrandManifesto() {
  return (
    <section className="py-40 bg-black text-white text-center px-6">
      <motion.h2
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="text-6xl md:text-7xl font-black tracking-tighter italic uppercase mb-8"
      >
        Built For The
        <br />
        Relentless.
      </motion.h2>

      <p className="max-w-3xl mx-auto text-neutral-400 text-lg leading-relaxed">
        3DX PARTICLES is not clothing.  
        It is engineered identity for people who reject average.
        Precision design. Cyber-aesthetic engineering. Zero compromise.
      </p>
    </section>
  );
}
