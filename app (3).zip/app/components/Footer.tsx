"use client";

import React, { useState } from "react";
import { motion } from "framer-motion";
import Link from "next/link";

export default function Footer() {
  const [email, setEmail] = useState("");
  const [status, setStatus] = useState("WAITING_FOR_INPUT");

  const handleJoin = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      setStatus("ACCESS_GRANTED");
      setTimeout(() => setStatus("WAITING_FOR_INPUT"), 3000);
      setEmail("");
    }
  };

  return (
    <footer className="w-full bg-black text-white relative overflow-hidden border-t border-white/20 z-20">
      
      {/* 1. TOP GRID SECTION */}
      <div className="grid grid-cols-1 md:grid-cols-4 divide-y md:divide-y-0 md:divide-x divide-white/20">
        
        {/* COL 1: BRAND MANIFESTO */}
        <div className="p-10 flex flex-col justify-between h-full min-h-[300px]">
          <div>
            <div className="w-8 h-8 bg-white rounded-full mb-6 animate-pulse" />
            <p className="text-neutral-400 font-mono text-xs leading-relaxed uppercase tracking-wide">
              Defining the aesthetic of the post-digital age. <br/>
              Engineered in Tokyo. <br/>
              Operating Worldwide.
            </p>
          </div>
          <div className="font-mono text-xs text-neutral-600 mt-10">
            <p>EST. 2024</p>
            <p>SECTOR 7G</p>
          </div>
        </div>

        {/* COL 2: SHOP LINKS (Updated to Dynamic Routes) */}
        <div className="p-10 flex flex-col gap-6">
          <h3 className="font-bold text-neutral-500 uppercase tracking-widest text-xs font-mono mb-4">
            /// DIRECTORY
          </h3>
          {[
            { name: "New Arrivals", slug: "new-arrivals" },
            { name: "Best Sellers", slug: "best-sellers" },
            { name: "Accessories", slug: "accessories" },
            { name: "Archive", slug: "archive" },
          ].map((link) => (
            <Link 
              key={link.name} 
              href={`/shop/${link.slug}`} 
              className="group flex items-center gap-2 text-lg font-bold hover:text-neutral-400 transition-colors"
            >
              <span className="w-0 overflow-hidden group-hover:w-4 transition-all duration-300 text-neutral-500">→</span>
              {link.name}
            </Link>
          ))}
          <Link href="/shop" className="group flex items-center gap-2 text-sm font-mono text-neutral-500 hover:text-white transition-colors uppercase italic">
            View All Units
          </Link>
        </div>

        {/* COL 3: SUPPORT LINKS (Updated to Support Routes) */}
        <div className="p-10 flex flex-col gap-6">
          <h3 className="font-bold text-neutral-500 uppercase tracking-widest text-xs font-mono mb-4">
            /// SYSTEM
          </h3>
          {[
            { name: "Track Order", path: "/support/track" },
            { name: "Returns & Exchanges", path: "/support/returns" },
            { name: "Shipping Info", path: "/support/shipping" },
            { name: "Contact Protocol", path: "/support/contact" },
          ].map((link) => (
            <Link 
              key={link.name} 
              href={link.path} 
              className="text-neutral-400 hover:text-white transition-colors text-sm font-medium uppercase tracking-tighter"
            >
              {link.name}
            </Link>
          ))}
          <Link href="/support" className="text-green-500 hover:text-green-400 transition-colors text-sm font-bold uppercase tracking-tighter flex items-center gap-2">
            <span className="animate-pulse">●</span> Terminal FAQ
          </Link>
        </div>

        {/* COL 4: COMMAND CENTER FOOTER (Newsletter) */}
        <div className="p-10 flex flex-col justify-between bg-white/[0.02]">
          <div>
            <h3 className="font-bold text-white uppercase text-2xl mb-2 tracking-tighter">
              Command_Center
            </h3>
            <p className="text-neutral-500 font-mono text-[10px] uppercase mb-8">
              Protocol: Register email for stealth drops.
            </p>
          </div>

          <form onSubmit={handleJoin} className="relative group p-4 border border-white/10 bg-black">
            <div className="flex justify-between items-center mb-4 border-b border-white/10 pb-2">
              <span className="font-mono text-[10px] text-neutral-600">STATUS: {status}</span>
              <div className="flex gap-1">
                <div className="w-1.5 h-1.5 rounded-full bg-red-500/50" />
                <div className="w-1.5 h-1.5 rounded-full bg-yellow-500/50" />
                <div className="w-1.5 h-1.5 rounded-full bg-green-500/50" />
              </div>
            </div>
            
            <div className="relative">
              <span className="absolute left-0 top-1/2 -translate-y-1/2 text-green-500 font-mono text-xs">{">"}</span>
              <input 
                type="email" 
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="USER@NETWORK.COM" 
                className="w-full bg-transparent py-2 pl-6 text-green-500 font-mono text-xs placeholder-green-900 focus:outline-none transition-colors"
              />
            </div>
            
            <button 
              type="submit"
              className="w-full mt-4 bg-green-500 text-black py-2 font-mono text-[10px] font-bold uppercase hover:bg-white transition-all"
            >
              Execute_Join
            </button>
          </form>
        </div>

      </div>

      {/* 2. MASSIVE TYPOGRAPHY */}
      <div className="border-t border-white/20">
        <h1 className="text-[12vw] leading-[0.8] font-black tracking-tighter text-center uppercase py-4 select-none mix-blend-difference text-white">
          ORBIT STUDIOS
        </h1>
      </div>

      {/* 3. BOTTOM BAR */}
      <div className="border-t border-white/20 p-6 flex flex-col md:flex-row justify-between items-center text-[10px] font-mono text-neutral-500 uppercase tracking-widest">
        <div className="flex gap-4">
          <span>© 2025 ORBIT STUDIOS</span>
          <span className="hidden md:inline">///</span>
          <span>PRIVACY POLICY</span>
          <span className="hidden md:inline">///</span>
          <span>TERMS OF USE</span>
        </div>
        
        <div className="flex items-center gap-2 mt-4 md:mt-0">
          <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
          <span>SYSTEMS NORMAL</span>
        </div>
      </div>

    </footer>
  );
}