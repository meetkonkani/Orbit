"use client";

import { motion } from "framer-motion";

const images = [
  {
    src: "https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?q=80&w=800&auto=format&fit=crop",
    title: "NEO_CORE",
    id: "001"
  },
  {
    src: "https://images.unsplash.com/photo-1532453288672-3a27e9be9efd?q=80&w=800&auto=format&fit=crop",
    title: "ACC_SYSTEM",
    id: "002"
  },
  {
    src: "https://images.unsplash.com/photo-1550973886-98c535044d2b?q=80&w=800&auto=format&fit=crop",
    title: "DARK_ESTH",
    id: "003"
  }
];

export default function Gallery() {
  return (
    <section className="bg-black py-20 px-6 md:px-20 relative z-20 border-t border-white/10">
      
      <div className="mb-20 max-w-4xl">
        <span className="font-mono text-xs text-green-500 mb-4 tracking-[0.3em] block">/// VISUAL_ARCHIVE_ACCESS</span>
        <h2 className="text-6xl md:text-8xl font-black uppercase leading-none text-white tracking-tighter">
          THE FILM<br/>
          STRIP<span className="text-neutral-700">.</span>
        </h2>
      </div>

      <div className="flex flex-col gap-32 md:gap-64">
        {images.map((item, i) => (
          <motion.div 
            key={i}
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: false, amount: 0.2 }}
            transition={{ duration: 0.8 }}
            className={`flex flex-col md:flex-row items-center gap-10 ${
              i % 2 === 0 ? "md:justify-start" : "md:justify-end"
            }`}
          >
            {/* IMAGE CONTAINER WITH GLITCH HOVER */}
            <div className="relative w-full md:w-[50vw] h-[60vh] md:h-[80vh] overflow-hidden group border border-white/10 bg-neutral-900">
              
              {/* The Main Image */}
              <img 
                src={item.src} 
                alt={item.title} 
                className="w-full h-full object-cover grayscale transition-all duration-700 group-hover:grayscale-0 group-hover:scale-105"
              />

              {/* CYBERPUNK SCANLINE EFFECT */}
              <div className="absolute inset-0 pointer-events-none bg-gradient-to-b from-transparent via-white/5 to-transparent h-20 w-full -translate-y-full group-hover:animate-scanline" />
              
              {/* RGB OVERLAY (Glitch effect on hover) */}
              <div className="absolute inset-0 opacity-0 group-hover:opacity-20 pointer-events-none mix-blend-screen transition-opacity">
                <img src={item.src} className="absolute inset-0 w-full h-full object-cover scale-105 translate-x-1" alt="" />
                <img src={item.src} className="absolute inset-0 w-full h-full object-cover scale-105 -translate-x-1" alt="" />
              </div>

              <div className="absolute top-6 left-6 font-mono text-[10px] text-white/50 bg-black/60 backdrop-blur-md px-3 py-1">
                DATA_STREAM // {item.id}
              </div>
            </div>

            <div className={`flex flex-col ${i % 2 === 0 ? "md:text-left" : "md:text-right md:order-first"}`}>
               <h3 className="text-3xl font-black tracking-tighter uppercase text-white mb-2">{item.title}</h3>
               <p className="font-mono text-[10px] text-neutral-500 uppercase tracking-widest">
                  Orb_Studios // Season_04 <br/> 
                  Sector_7G // Tokyo_Unit
               </p>
            </div>
          </motion.div>
        ))}
      </div>
    </section>
  );
}