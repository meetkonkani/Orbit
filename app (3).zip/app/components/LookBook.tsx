"use client";

import { motion } from "framer-motion";
import { useRef } from "react";
import { useRouter } from "next/navigation";
import { PRODUCTS } from "@/app/lib/data"; // 👈 Fetching from your static file

export default function Lookbook() {
  const scrollRef = useRef<HTMLDivElement>(null);
  const router = useRouter();

  // Only take the first 5 products from your lib/data.ts file
  const looks = PRODUCTS.slice(0, 5);

  return (
    <section className="py-32 relative z-20 border-t border-white/10 bg-black">
      <div className="px-6 md:px-10 mb-12 flex justify-between items-end max-w-6xl mx-auto">
        <div>
          <h2 className="text-4xl font-bold tracking-tight text-white uppercase mb-2">
            Season 04 Lookbook
          </h2>
          <p className="text-neutral-400 font-mono text-sm">
            FIELD TEST DATA // TERRAFORMA
          </p>
        </div>
      </div>

      <div 
        ref={scrollRef}
        className="flex overflow-x-auto gap-4 px-6 md:px-10 no-scrollbar snap-x snap-mandatory scroll-pl-6 md:scroll-pl-10"
      >
        {looks.map((look, i) => (
          <motion.div
            key={look.id}
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: i * 0.1 }}
            
            // ✅ FIX: This matches the IDs in your lib/data.ts exactly
            onClick={() => router.push(`/products/${look.id}`)}
            
            className="relative flex-shrink-0 w-[300px] md:w-[450px] h-[500px] md:h-[700px] bg-neutral-900 border border-white/10 snap-start group overflow-hidden cursor-pointer"
          >
            <img 
              src={look.image} 
              alt={look.title}
              className="object-cover w-full h-full grayscale group-hover:grayscale-0 transition-all duration-700"
            />
            
            <div className="absolute bottom-0 left-0 p-8 w-full z-10">
              <span className="font-mono text-xs text-neutral-400 block mb-2">LOOK {i + 1}</span>
              <h3 className="font-bold text-2xl text-white uppercase tracking-widest">{look.title}</h3>
            </div>
          </motion.div>
        ))}
        <div className="flex-shrink-0 w-6 md:w-10" />
      </div>
    </section>
  );
}