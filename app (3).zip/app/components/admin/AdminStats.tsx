"use client";

import { motion } from "framer-motion";

interface AdminStatsProps {
  stats: {
    orders: number;
    users: number;
    products: number;
    revenue: number;
  };
}

export default function AdminStats({ stats }: AdminStatsProps) {
  const cardData = [
    { 
      label: "Total Revenue", 
      value: `$${stats.revenue.toLocaleString(undefined, { minimumFractionDigits: 2 })}`, 
      color: "text-green-400" 
    },
    { label: "Total Orders", value: stats.orders, color: "text-blue-400" },
    { label: "Active Users", value: stats.users, color: "text-purple-400" },
    { label: "Products", value: stats.products, color: "text-orange-400" },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
      {cardData.map((stat, i) => (
        <motion.div
          key={stat.label}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: i * 0.1 }}
          className="p-6 bg-white/5 border border-white/10 rounded-2xl backdrop-blur-sm shadow-xl"
        >
          <p className="text-neutral-400 text-sm font-medium">{stat.label}</p>
          <p className={`text-2xl font-bold mt-2 ${stat.color}`}>
            {stat.value}
          </p>
        </motion.div>
      ))}
    </div>
  );
}