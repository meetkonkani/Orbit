"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { createProduct, updateProduct, deleteImageFromUT, ActionResult } from "@/app/actions/admin";
import { UploadDropzone } from "@/app/lib/uploadthing";
import Image from "next/image";
import { X, Loader2 } from "lucide-react";

interface Product {
  id: string;
  title: string;
  description: string;
  price: number;
  category: string;
  stock: number;
  images: string[];
}

export default function ProductForm({ initialData }: { initialData?: Product | null }) {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [deletingImage, setDeletingImage] = useState<string | null>(null);
  const [error, setError] = useState("");
  const [images, setImages] = useState<string[]>(initialData?.images || []);

  async function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setLoading(true);
    setError("");

    if (images.length === 0) {
      setError("Please upload at least one image.");
      setLoading(false);
      return;
    }

    const formData = new FormData(e.currentTarget);
    const data = {
      title: formData.get("title") as string,
      category: formData.get("category") as string,
      price: formData.get("price") as string,
      stock: formData.get("stock") as string,
      description: formData.get("description") as string,
      images: images,
    };

    const result: ActionResult = initialData
      ? await updateProduct(initialData.id, data)
      : await createProduct(data);

    if (result.error) {
      setError(result.error);
      setLoading(false);
    } else {
      router.push("/admin/products");
      router.refresh();
    }
  }

  // UPDATED: Async removal from storage
  const removeImage = async (index: number) => {
    const urlToRemove = images[index];
    setDeletingImage(urlToRemove);
    
    try {
      // This wipes the file from UploadThing servers immediately
      await deleteImageFromUT(urlToRemove);
      setImages(images.filter((_, i) => i !== index));
    } catch (err) {
      setError("Failed to remove image from server.");
    } finally {
      setDeletingImage(null);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-8 text-white bg-neutral-900 p-8 rounded-2xl border border-white/10 shadow-2xl max-w-5xl mx-auto">
      <h2 className="text-2xl font-black uppercase tracking-tighter italic">
        {initialData ? "Edit Product" : "Add New Product"}
      </h2>

      {error && (
        <div className="p-4 bg-red-500/20 text-red-400 rounded-lg text-sm border border-red-500/50 font-bold">
          {error}
        </div>
      )}

      <div className="space-y-4">
        <label className="text-xs font-black uppercase tracking-widest text-neutral-400">
          Product Visuals
        </label>

        {images.length > 0 && (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
            {images.map((url, index) => (
              <div key={url} className="relative aspect-square rounded-xl overflow-hidden border border-white/10 group bg-black">
                <Image
                  src={url}
                  alt="Preview"
                  fill
                  unoptimized
                  className={`object-cover transition-transform group-hover:scale-110 ${deletingImage === url ? 'opacity-50' : ''}`}
                />
                <button
                  type="button"
                  disabled={deletingImage === url}
                  onClick={() => removeImage(index)}
                  className="absolute top-2 right-2 p-1.5 bg-red-600 text-white rounded-full opacity-0 group-hover:opacity-100 transition-all z-20 shadow-xl disabled:bg-neutral-600"
                >
                  {deletingImage === url ? <Loader2 size={16} className="animate-spin" /> : <X size={16} />}
                </button>
              </div>
            ))}
          </div>
        )}

        <div className="bg-white/5 border-2 border-dashed border-white/10 rounded-2xl overflow-hidden transition-colors hover:border-white/20">
          <UploadDropzone
            endpoint="imageUploader"
            onClientUploadComplete={(res) => {
              setImages((prev) => [...prev, ...res.map((f) => f.url)]);
            }}
            onUploadError={(err) => setError(err.message)}
            appearance={{
              container: "flex flex-col items-center justify-center p-12 min-h-[240px] border-none",
              label: "text-white font-bold text-lg mb-2 block",
              allowedContent: "text-neutral-500 text-[10px] uppercase font-black tracking-widest mt-1",
              button: "ut-uploading:bg-neutral-400 !bg-white !text-black !font-black px-10 py-3 rounded-full hover:!bg-neutral-200 transition-all mt-6 shadow-xl relative z-10",
            }}
            content={{
              button({ isUploading, uploadProgress }) {
                if (isUploading) return (
                  <div className="!text-black uppercase flex gap-2">
                    <span>Uploading</span>
                    <span className="tabular-nums">{uploadProgress}%</span>
                  </div>
                );
                return <span className="!text-black uppercase">Select Files</span>;
              },
            }}
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="space-y-2">
          <label className="text-xs font-black uppercase tracking-widest text-neutral-400">Product Title</label>
          <input name="title" defaultValue={initialData?.title} required className="w-full bg-black/50 border border-white/10 rounded-xl px-4 py-4 !text-white outline-none focus:border-white/40 font-medium" />
        </div>
        <div className="space-y-2">
          <label className="text-xs font-black uppercase tracking-widest text-neutral-400">Category</label>
          <select name="category" defaultValue={initialData?.category || "hoodies"} className="w-full bg-black/50 border border-white/10 rounded-xl px-4 py-4 !text-white outline-none cursor-pointer appearance-none">
            <option value="hoodies">Hoodies</option>
            <option value="t-shirts">T-Shirts</option>
            <option value="accessories">Accessories</option>
          </select>
        </div>
        <div className="space-y-2">
          <label className="text-xs font-black uppercase tracking-widest text-neutral-400">Price (USD)</label>
          <input name="price" type="number" step="0.01" defaultValue={initialData?.price || ""} required className="w-full bg-black/50 border border-white/10 rounded-xl px-4 py-4 !text-white outline-none font-bold" />
        </div>
        <div className="space-y-2">
          <label className="text-xs font-black uppercase tracking-widest text-neutral-400">Stock Available</label>
          <input name="stock" type="number" defaultValue={initialData?.stock} required className="w-full bg-black/50 border border-white/10 rounded-xl px-4 py-4 !text-white outline-none" />
        </div>
      </div>

      <div className="space-y-2">
        <label className="text-xs font-black uppercase tracking-widest text-neutral-400">Detailed Description</label>
        <textarea name="description" defaultValue={initialData?.description} rows={5} className="w-full bg-black/50 border border-white/10 rounded-xl px-4 py-4 !text-white outline-none resize-none" />
      </div>

      <button
        type="submit"
        disabled={loading}
        className="group relative w-full !bg-white !text-black py-5 rounded-xl transition-all hover:!bg-neutral-200 active:scale-[0.98] disabled:opacity-50 shadow-[0_0_30px_rgba(255,255,255,0.05)]"
      >
        <div className="flex items-center justify-center gap-3">
          {loading ? (
            <>
              <Loader2 className="animate-spin !text-black" size={24} />
              <span className="!text-black font-black uppercase tracking-[0.2em] text-lg">Processing</span>
            </>
          ) : (
            <span className="!text-black font-black uppercase tracking-[0.2em] text-lg">
              {initialData ? "Confirm Update" : "Publish Product"}
            </span>
          )}
        </div>
      </button>
    </form>
  );
}