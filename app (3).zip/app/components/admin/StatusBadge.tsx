"use client";

type Status = "PENDING" | "PAID" | "SHIPPED" | "DELIVERED" | "CANCELLED";

export default function StatusBadge({ status }: { status: Status }) {
  const styles: Record<Status, string> = {
    PENDING: "bg-yellow-500/10 text-yellow-500 border-yellow-500/20",
    PAID: "bg-green-500/10 text-green-500 border-green-500/20",
    SHIPPED: "bg-blue-500/10 text-blue-500 border-blue-500/20",
    DELIVERED: "bg-purple-500/10 text-purple-500 border-purple-500/20",
    CANCELLED: "bg-red-500/10 text-red-500 border-red-500/20",
  };

  return (
    <span className={`text-[10px] font-bold px-2 py-1 rounded-full border uppercase tracking-wider ${styles[status]}`}>
      {status}
    </span>
  );
}