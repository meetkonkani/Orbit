"use client"; // ✅ This allows interactivity

import { updateOrderStatus } from "@/app/actions/admin";

export default function StatusSelect({ orderId, currentStatus }: { orderId: string, currentStatus: string }) {
  return (
    <select 
      defaultValue={currentStatus}
      onChange={async (e) => {
        await updateOrderStatus(orderId, e.target.value);
      }}
      className="w-full bg-black border border-white/10 rounded-lg p-2 text-sm outline-none focus:border-white/30"
    >
      <option value="PENDING">Pending</option>
      <option value="PAID">Paid</option>
      <option value="SHIPPED">Shipped</option>
      <option value="DELIVERED">Delivered</option>
      <option value="CANCELLED">Cancelled</option>
    </select>
  );
}