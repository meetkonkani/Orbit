export async function saasFetch(path: string) {
  const token = localStorage.getItem("saas_token");

  const res = await fetch(`http://localhost:8000${path}`, {
    headers: { Authorization: `Bearer ${token}` },
  });

  return res.json();
}
