// app/middleware.ts
import NextAuth from "next-auth";
import { authConfig } from "./auth.config";

export default NextAuth(authConfig).auth;

export const config = {
  matcher: [
    /*
     * Match all request paths except for:
     * - api/auth (NextAuth)
     * - api/uploadthing (UploadThing) <--- ADD THIS
     * - _next/static, _next/image, favicon.ico, etc.
     */
    "/((?!api/auth|api/uploadthing|_next/static|_next/image|favicon.ico|globe.svg).*)",
  ],
};