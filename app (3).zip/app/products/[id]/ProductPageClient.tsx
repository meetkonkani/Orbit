"use client";

import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { toast } from "sonner";
import { useCart } from "@/app/context/CartContext";
import { ChevronDown, ArrowLeft, ArrowRight, ChevronLeft, ChevronRight } from "lucide-react";
import Link from "next/link";
import { useRouter } from "next/navigation";

export default function ProductPageClient({ product, relatedProducts }: any) {
  const router = useRouter();
  const { addToCart } = useCart();

  const [size, setSize] = useState("M");
  const [[page, direction], setPage] = useState([0, 0]);
  const [openAccordion, setOpenAccordion] = useState<string | null>("details");

  const images =
    Array.isArray(product.images) && product.images.length > 0
      ? product.images
      : ["/fallback.jpg"]; // 🔥 add any image inside /public/fallback.jpg

  const imageIndex = Math.abs(page % images.length);

  const paginate = (newDirection: number) => {
    setPage([page + newDirection, newDirection]);
  };

  const handleAddToCart = () => {
    if (product.stock <= 0) return;

    addToCart({
      id: product.id,
      title: product.title,
      price: product.price,
      image: images[imageIndex],
      size,
      quantity: 1,
    });
    toast.success("Added to cart", { description: product.title });
  };

  const sliderVariants = {
    enter: (direction: number) => ({
      x: direction > 0 ? 300 : -300,
      opacity: 0,
    }),
    center: { zIndex: 1, x: 0, opacity: 1 },
    exit: (direction: number) => ({
      zIndex: 0,
      x: direction < 0 ? 300 : -300,
      opacity: 0,
    }),
  };

  return (
    <main className="min-h-screen bg-black text-white">
      <div className="flex flex-col lg:flex-row min-h-screen">
        {/* LEFT IMAGE SLIDER */}
        <div className="w-full lg:w-1/2 bg-[#0a0a0a] relative border-r border-white/10 flex items-center justify-center min-h-[65vh]">
          <button
            onClick={() => router.back()}
            className="absolute top-8 left-8 z-30 bg-black/40 backdrop-blur-md px-4 py-2 border border-white/20 text-[10px] uppercase tracking-widest hover:bg-white hover:text-black transition-all flex items-center gap-2"
          >
            <ArrowLeft size={12} /> Back
          </button>

          {images.length > 1 && (
            <div className="absolute inset-x-0 top-1/2 -translate-y-1/2 flex justify-between px-4 z-20">
              <button onClick={() => paginate(-1)} className="p-3 bg-white/10 border">
                <ChevronLeft size={20} />
              </button>
              <button onClick={() => paginate(1)} className="p-3 bg-white/10 border">
                <ChevronRight size={20} />
              </button>
            </div>
          )}

          <div className="relative w-full h-full flex items-center justify-center p-12">
            <AnimatePresence initial={false} custom={direction}>
              <motion.img
                key={page}
                src={images[imageIndex]}
                custom={direction}
                variants={sliderVariants}
                initial="enter"
                animate="center"
                exit="exit"
                transition={{ x: { type: "spring", stiffness: 260, damping: 30 }, opacity: { duration: 0.2 } }}
                className="max-h-[75vh] object-contain"
              />
            </AnimatePresence>
          </div>
        </div>

        {/* RIGHT PRODUCT DETAILS */}
        <div className="w-full lg:w-1/2 p-12">
          <h1 className="text-6xl font-black italic uppercase mb-6">{product.title}</h1>
          <p className="text-3xl mb-2">₹{product.price.toLocaleString("en-IN")}</p>

          <div className="mb-6 text-xs text-neutral-400 space-y-1">
            <p>🚚 Free Shipping over ₹999</p>
            <p>💳 Cash on Delivery Available</p>
            <p>🔁 7-Day Easy Returns</p>
          </div>

          <div className="grid grid-cols-4 gap-2 mb-10">
            {["S", "M", "L", "XL"].map((s) => (
              <button
                key={s}
                onClick={() => setSize(s)}
                className={`border py-4 ${size === s ? "bg-white text-black" : "border-white/20"}`}
              >
                {s}
              </button>
            ))}
          </div>

          <button
            onClick={handleAddToCart}
            disabled={product.stock <= 0}
            className={`w-full py-5 font-bold uppercase tracking-widest ${
              product.stock > 0 ? "bg-white text-black" : "bg-neutral-700 text-neutral-400"
            }`}
          >
            {product.stock > 0 ? "Add To Cart" : "Out of Stock"}
          </button>

          {/* RELATED */}
          <section className="mt-24">
            <h2 className="text-xs uppercase tracking-[0.4em] text-neutral-600 mb-6">Related</h2>
            <div className="grid grid-cols-2 gap-6">
              {relatedProducts.map((p: any) => (
                <Link key={p.id} href={`/products/${p.id}`}>
                  <img src={p.images?.[0] || "/fallback.jpg"} className="mb-2" />
                  <p className="text-xs">{p.title}</p>
                </Link>
              ))}
            </div>
          </section>
        </div>
      </div>
    </main>
  );
}
