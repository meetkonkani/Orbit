import { prisma } from "@/app/lib/prisma";
import { notFound } from "next/navigation";
import ProductPageClient from "./ProductPageClient";

export default async function ProductPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;

  const product = await prisma.product.findUnique({
    where: { id },
  });

  if (!product) notFound();

  const relatedProducts = await prisma.product.findMany({
    where: {
      category: product.category,
      NOT: { id: product.id },
    },
    take: 4,
  });

  const serialize = (p: any) => ({
    ...p,
    price: Number(p.price),
    createdAt: p.createdAt?.toISOString(),
    updatedAt: p.updatedAt?.toISOString(),
  });

  return (
    <ProductPageClient
      product={serialize(product)}
      relatedProducts={relatedProducts.map(serialize)}
    />
  );
}
