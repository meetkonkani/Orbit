"use client";

import { motion } from "framer-motion";
import Link from "next/link";
import { useEffect, useRef, useState } from "react";
import CustomCursor from "../components/CustomCursor";
import { useCart } from "../context/CartContext";

export default function SuccessPage() {
  const [greeting, setGreeting] = useState("");
  const fullText = "WELCOME BACK, AGENT. MISSION STATUS: COMPLETE.";

  const { clearCart } = useCart();

  // 🔐 Prevent double execution (React Strict Mode)
  const clearedRef = useRef(false);

  useEffect(() => {
    if (!clearedRef.current) {
      clearCart();
      clearedRef.current = true;
    }
  }, [clearCart]);

  useEffect(() => {
    let i = 0;
    const interval = setInterval(() => {
      setGreeting(fullText.slice(0, i));
      i++;
      if (i > fullText.length) clearInterval(interval);
    }, 50);
    return () => clearInterval(interval);
  }, []);

  return (
    <main className="h-screen bg-black text-white flex flex-col items-center justify-center p-6 relative overflow-hidden">
      <CustomCursor />

      {/* TOP LEFT STATUS */}
      <div className="absolute top-10 left-10 font-mono text-[10px] text-green-500 uppercase tracking-widest hidden md:block">
        <p>Identity: Verified</p>
        <p className="opacity-50">Connection: Secure</p>
      </div>

      <div className="max-w-2xl w-full text-center z-10">
        {/* TYPEWRITER GREETING */}
        <p className="font-mono text-xs text-green-500 mb-6 min-h-[1em]">
          {greeting}
          <span className="animate-pulse">_</span>
        </p>

        <motion.h1
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="text-6xl md:text-8xl font-black uppercase tracking-tighter mb-8 italic"
        >
          YOU&apos;RE IN.
        </motion.h1>

        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1 }}
          className="text-neutral-400 text-sm md:text-base mb-12 max-w-md mx-auto leading-relaxed"
        >
          Your acquisition is being synchronized with our logistics grid.
          Expect a transmission once the gear is in transit.
        </motion.p>

        {/* INTERACTIVE DATA LOG */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.5 }}
          className="grid grid-cols-2 gap-px bg-white/10 border border-white/10 mb-12 overflow-hidden"
        >
          {[
            { label: "Client ID", val: "USER_#882" },
            { label: "Deployment", val: "3-5 Cycles" },
            { label: "Sector", val: "Global" },
            { label: "Payment", val: "Authorized" },
          ].map((item, i) => (
            <div
              key={i}
              className="bg-black p-4 hover:bg-green-500/5 transition-colors group"
            >
              <p className="font-mono text-[8px] text-neutral-500 uppercase group-hover:text-green-500">
                {item.label}
              </p>
              <p className="font-mono text-xs text-white uppercase mt-1">
                {item.val}
              </p>
            </div>
          ))}
        </motion.div>

        {/* CTA */}
        <Link href="/">
          <motion.button
            whileHover={{ scale: 1.05, backgroundColor: "#fff", color: "#000" }}
            whileTap={{ scale: 0.95 }}
            className="border border-white text-white px-12 py-4 font-bold uppercase tracking-widest text-xs transition-all"
          >
            End Session & Return
          </motion.button>
        </Link>
      </div>

      {/* SCANLINE OVERLAY */}
      <div className="absolute inset-0 pointer-events-none bg-[linear-gradient(rgba(18,16,16,0)_50%,rgba(0,0,0,0.25)_50%),linear-gradient(90deg,rgba(255,0,0,0.06),rgba(0,255,0,0.02),rgba(0,0,255,0.06))] z-20 bg-[length:100%_2px,3px_100%] opacity-20" />
    </main>
  );
}
