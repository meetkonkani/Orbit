import { prisma } from "@/app/lib/prisma";
import { notFound } from "next/navigation";
import Image from "next/image";
import { updateOrderStatus, deleteOrder } from "@/app/actions/admin";

type OrderItem = {
  id: string;
  title: string;
  image: string;
  size: string;
  quantity: number;
};

type AdminOrder = {
  id: string;
  status: string;
  shippingName: string;
  shippingPhone: string;
  shippingAddress: string;
  shippingCity: string;
  shippingPincode: string;
  items: OrderItem[];
};

export default async function OrderDetailsPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const resolvedParams = await params;
  const id = resolvedParams.id;

  const rawOrder = await prisma.order.findUnique({
    where: { id },
    include: { items: true },
  });

  if (!rawOrder) notFound();

  const order: AdminOrder = {
    id: rawOrder.id,
    status: rawOrder.status,
    shippingName: rawOrder.shippingName ?? "",
    shippingPhone: rawOrder.shippingPhone ?? "",
    shippingAddress: rawOrder.shippingAddress ?? "",
    shippingCity: rawOrder.shippingCity ?? "",
    shippingPincode: rawOrder.shippingPincode ?? "",
    items: rawOrder.items.map(i => ({
      id: i.id,
      title: i.title,
      image: i.image,
      size: i.size,
      quantity: Number(i.quantity),
    })),
  };

  return (
    <div className="p-8 max-w-4xl mx-auto text-white">
      <h1 className="text-3xl font-bold mb-6 uppercase">
        Order #{order.id.slice(-6)}
      </h1>

      <div className="mb-8 bg-white/5 p-6 rounded-xl">
        <p><b>Name:</b> {order.shippingName}</p>
        <p><b>Phone:</b> {order.shippingPhone}</p>
        <p><b>Address:</b> {order.shippingAddress}</p>
        <p><b>City:</b> {order.shippingCity}</p>
        <p><b>Pincode:</b> {order.shippingPincode}</p>
      </div>

      {order.items.map(item => (
        <div key={item.id} className="flex gap-4 mb-4 bg-white/5 p-4 rounded-xl">
          <Image src={item.image} alt={item.title} width={80} height={80} />
          <div>
            <p>{item.title}</p>
            <p className="text-xs text-neutral-400">
              {item.size} × {item.quantity}
            </p>
          </div>
        </div>
      ))}

<form
  action={async (data) => {
    "use server";
    const status = data.get("status") as string;
    await updateOrderStatus(order.id, status);
  }}
  className="mt-8 space-y-3"
>
  <select
    name="status"
    defaultValue={order.status}
    className="p-3 bg-black border border-white/10"
  >
    <option>PENDING</option>
    <option>PAID</option>
    <option>SHIPPED</option>
    <option>DELIVERED</option>
    <option>CANCELLED</option>
  </select>

  <button className="ml-4 bg-white text-black px-6 py-2">
    Update Status
  </button>
</form>

<form
  action={async () => {
    "use server";
    await deleteOrder(order.id);
  }}
>
  <button className="mt-6 bg-red-500/30 text-red-400 px-6 py-2">
    Delete Order
  </button>
</form>
    </div>
  );
}
