import { prisma } from "@/app/lib/prisma";

type StatusGroup = {
  status: string;
  _count: { status: number };
};

export default async function AdminDashboard() {

  const stats = await prisma.order.aggregate({
    _sum: { total: true },
    _count: { id: true },
  });

  // 👇 FORCE CAST – this is the missing piece
  const rawGroup = (await prisma.order.groupBy({
    by: ["status"],
    _count: { status: true },
  })) as unknown as {
    status: string;
    _count: { status: number };
  }[];

  const statusGroup: StatusGroup[] = rawGroup.map((g) => ({
    status: g.status,
    _count: { status: Number(g._count.status) },
  }));

  const totalRevenue = Number(stats._sum.total || 0);
  const totalOrders = Number(stats._count.id || 0);

  return (
    <div className="p-8 text-white">
      <h1 className="text-3xl font-bold mb-8">Analytics Hub</h1>

      {statusGroup.map((group) => (
        <div key={group.status} className="mb-4">
          <div className="flex justify-between text-xs">
            <span>{group.status}</span>
            <span>{group._count.status}</span>
          </div>
          <div className="h-1 bg-white/20">
            <div
              className="h-full bg-white"
              style={{
                width: totalOrders
                  ? `${(group._count.status / totalOrders) * 100}%`
                  : "0%",
              }}
            />
          </div>
        </div>
      ))}
    </div>
  );
}
