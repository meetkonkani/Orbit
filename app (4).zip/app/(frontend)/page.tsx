"use client";

import React, { useState } from "react";
import { motion } from "framer-motion";
import { useRouter } from "next/navigation";

import ParticleSphere from "../components/ParticleSphere";
import MagneticButton from "../components/MagneticButton";
import ContactModal from "../components/ContactModal";
import Preloader from "../components/Preloader";
import HyperText from "../components/HyperText";
import Lookbook from "../components/LookBook";
import Gallery from "../components/Gallery";
import BrandManifesto from "../components/BrandManifesto";

function SectionHeader({ title, subtitle, align = "left" }: { title: string; subtitle: string; align?: "left" | "right" }) {
  return (
    <div className={`px-6 md:px-20 mb-12 flex flex-col ${align === "right" ? "items-end text-right" : "items-start"}`}>
      <span className="font-mono text-[10px] text-green-500 tracking-[0.4em] uppercase mb-2">// {subtitle}</span>
      <h2 className="text-5xl md:text-7xl font-black uppercase tracking-tighter text-white">{title}</h2>
    </div>
  );
}

export default function Homepage() {
  const router = useRouter();
  const [isModalOpen, setIsModalOpen] = useState(false);

  return (
    <main className="w-full min-h-screen bg-black relative selection:bg-white selection:text-black overflow-x-hidden">
      <Preloader />
      <ContactModal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} />

      {/* BACKGROUND LAYER */}
      <div className="fixed inset-0 z-0">
        <ParticleSphere />
      </div>

      <div className="relative z-10">

    {/* HERO SECTION */}
<section className="h-screen flex flex-col items-center justify-center text-center px-6">
  <motion.div 
    initial={{ opacity: 0, y: 20 }} 
    animate={{ opacity: 1, y: 0 }} 
    transition={{ duration: 1 }}
  >
    <p className="mb-6 text-[10px] font-mono tracking-[0.5em] text-neutral-500 uppercase">
      DROP SEASON_04
    </p>

    {/* REDUCED SIZE: Changed from text-[12vw] to md:text-8xl */}
    <h1 className="text-5xl md:text-8xl font-black tracking-tighter mb-8 leading-none">
      <HyperText text="Orbit." />
    </h1>

    <div onClick={() => router.push("/shop")} className="cursor-pointer inline-block">
      <MagneticButton>Access Drop</MagneticButton>
    </div>
  </motion.div>
</section>

        {/* LOOKBOOK: THE EDITORIAL STORY */}
        <section className="py-20">
          <SectionHeader title="The Looks" subtitle="EDITORIAL_ARCHIVE" />
          <Lookbook />
        </section>

        {/* MANIFESTO: THE PHILOSOPHY */}
        <BrandManifesto />

        {/* BRAND FILM SECTION */}
<section className="py-20 bg-black">
  <div className="px-6 md:px-20">
    <motion.div 
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.8 }}
      className="relative group w-full aspect-video md:h-[80vh] overflow-hidden rounded-sm border border-white/10"
    >
      {/* Brand Image Element */}
<motion.div 
  whileHover={{ scale: 1.02 }} // Subtle zoom on hover
  transition={{ duration: 0.5 }}
  className="w-full h-full"
>
  <img
    src="/brand.png" 
    alt="Orbit Brand Visual"
    className="w-full h-full object-cover grayscale hover:grayscale-0 transition-all duration-700"
  />
</motion.div>

      {/* Aesthetic Overlays */}
      <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent pointer-events-none" />
      
      {/* HUD / UI Elements to match your theme */}
      <div className="absolute top-6 left-6 flex items-center gap-3">
        <div className="w-2 h-2 bg-red-600 rounded-full animate-pulse" />
        <span className="font-mono text-[10px] text-white/50 tracking-[0.2em] uppercase">
          Live_Feed // Orbit_Archive_v04
        </span>
      </div>

      <div className="absolute bottom-6 right-6">
        <span className="font-mono text-[10px] text-white/30 uppercase">
          Resolution: 4K High-Bitrate
        </span>
      </div>
    </motion.div>
  </div>
</section>

        {/* GALLERY: THE TECHNICAL INDEX */}
        <section className="py-20 bg-[#050505]">
          <SectionHeader title="Index" subtitle="VISUAL_DATA_NODES" align="right" />
          <Gallery />
        </section>

        {/* FINAL CALL TO ACTION */}
        <section className="h-[80vh] flex flex-col items-center justify-center text-center border-t border-white/5 bg-black">
          <motion.div whileInView={{ opacity: 1, scale: 1 }} initial={{ opacity: 0, scale: 0.95 }} className="max-w-2xl px-6">
            <h2 className="text-5xl md:text-8xl font-black uppercase tracking-tighter mb-8">Join Orbit.</h2>
            <p className="text-neutral-500 font-mono text-xs uppercase tracking-widest mb-12">Precision engineered apparel. Priority access via terminal encryption.</p>
            <div onClick={() => setIsModalOpen(true)} className="cursor-pointer inline-block">
              <MagneticButton>Get Secure Access</MagneticButton>
            </div>
          </motion.div>
        </section>
      </div>
    </main>
  );
}