import crypto from "crypto";
import { NextResponse } from "next/server";
import { prisma } from "@/app/lib/prisma"; // Added prisma

export async function POST(req: Request) {
  const { razorpay_order_id, razorpay_payment_id, razorpay_signature } = await req.json();

  const body = razorpay_order_id + "|" + razorpay_payment_id;

  const expected = crypto
    .createHmac("sha256", process.env.RAZORPAY_KEY_SECRET!)
    .update(body)
    .digest("hex");

  if (expected !== razorpay_signature) {
    return NextResponse.json({ verified: false }, { status: 400 });
  }

  // INTEGRATION: Update the database order to PAID
  try {
    await prisma.order.update({
      where: { paymentId: razorpay_order_id }, // Ensure your order creation saves the razorpay_order_id here
      data: { status: "PAID" },
    });
    return NextResponse.json({ verified: true });
  } catch (err) {
    return NextResponse.json({ verified: true, dbError: "ORDER_NOT_UPDATED" });
  }
}