import { NextResponse } from "next/server";
import { transporter } from "@/app/lib/mailer";

export async function POST(req: Request) {
  const { to, orderId, total } = await req.json();

  await transporter.sendMail({
    from: `"3DX Particles" <${process.env.MAIL_USER}>`,
    to,
    subject: "Your Order is Confirmed",
    html: `
      <h2>Order Confirmed</h2>
      <p>Thank you for shopping with us.</p>
      <p><b>Order ID:</b> ${orderId}</p>
      <p><b>Total Paid:</b> ₹${total}</p>
    `,
  });

  return NextResponse.json({ success: true });
}
