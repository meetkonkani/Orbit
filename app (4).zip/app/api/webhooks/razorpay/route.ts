import { NextResponse } from "next/server";
import { prisma } from "@/app/lib/prisma";
import crypto from "crypto";

export async function POST(req: Request) {
  const body = await req.text();
  const signature = req.headers.get("x-razorpay-signature");

  // 1. Verify the webhook signature (Security)
  const expectedSignature = crypto
    .createHmac("sha256", process.env.RAZORPAY_WEBHOOK_SECRET!)
    .update(body)
    .digest("hex");

  if (signature !== expectedSignature) {
    return new NextResponse("Invalid signature", { status: 400 });
  }

  const event = JSON.parse(body);

  // 2. Handle successful payment
  if (event.event === "order.paid") {
    const paymentEntity = event.payload.payment.entity;
    const razorpayOrderId = paymentEntity.order_id;

    // Find our database order using the paymentId/OrderId mapping
    const order = await prisma.order.findFirst({
      where: { paymentId: razorpayOrderId },
      include: { items: true },
    });

    if (!order) return new NextResponse("Order not found", { status: 404 });
    if (order.status === "PAID") return new NextResponse("Already processed");

    try {
      // 3. ATOMIC TRANSACTION: Update Order + Reduce Stock
      await prisma.$transaction(async (tx) => {
        // Update Order Status
        await tx.order.update({
          where: { id: order.id },
          data: { status: "PAID" },
        });

        // Loop through items and decrement stock
        for (const item of order.items) {
          await tx.product.update({
            where: { id: item.productId },
            data: {
              stock: {
                decrement: item.quantity, // Prisma built-in decrement helper
              },
            },
          });
        }
      });

      return NextResponse.json({ success: true });
    } catch (error) {
      console.error("Stock update failed:", error);
      return new NextResponse("Internal Error", { status: 500 });
    }
  }

  return NextResponse.json({ received: true });
}