"use client";

import { motion } from "framer-motion";
import Image from "next/image";

const assets = [
  { src: "https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?q=80&w=800", code: "C_01" },
  { src: "https://images.unsplash.com/photo-1532453288672-3a27e9be9efd?q=80&w=800", code: "S_02" },
  { src: "https://images.unsplash.com/photo-1550973886-98c535044d2b?q=80&w=800", code: "D_03" },
  { src: "https://images.unsplash.com/photo-1591047139829-d91aecb6caea?q=80&w=800", code: "U_04" },
  { src: "https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?q=80&w=800", code: "C_05" },
  { src: "https://images.unsplash.com/photo-1532453288672-3a27e9be9efd?q=80&w=800", code: "S_06" },
];

export default function Gallery() {
  return (
    <section className="bg-black py-20 px-6 border-y border-white/5">
      <div className="grid grid-cols-1 md:grid-cols-3">
        {assets.map((item, i) => (
          <div key={i} className="group relative aspect-square border border-white/5 overflow-hidden">
            {/* STATIC TECHNICAL OVERLAY (Always Visible) */}
            <div className="absolute top-4 left-4 z-20 font-mono text-[8px] text-green-500 opacity-50">
              [ REF_{item.code} ]
            </div>
            
            <Image
              src={item.src}
              alt="Asset"
              fill
              className="object-cover opacity-40 group-hover:opacity-100 transition-opacity duration-700"
            />

            {/* HOVER SCANLINES */}
            <div className="absolute inset-0 bg-[linear-gradient(rgba(18,16,16,0)_50%,rgba(0,0,0,0.25)_50%),linear-gradient(90deg,rgba(255,0,0,0.06),rgba(0,255,0,0.02),rgba(0,0,255,0.06))] bg-[length:100%_2px,3px_100%] pointer-events-none opacity-0 group-hover:opacity-100 transition-opacity" />
          </div>
        ))}
      </div>
    </section>
  );
}