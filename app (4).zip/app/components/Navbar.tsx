"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useSession, signOut } from "next-auth/react";
import { User, LogOut, LayoutDashboard, ShoppingBag, Search, ChevronDown, Menu, X } from "lucide-react";
import { useCart } from "@/app/context/CartContext";
import { cn } from "@/app/lib/utils";

export default function Navbar() {
  const pathname = usePathname();
  const { data: session } = useSession();
  const { cart, openCart } = useCart();
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  // Switch styles if we are on dashboard or scrolled down
  const isLightPage = pathname.startsWith("/dashboard") || pathname.startsWith("/auth") || isScrolled;

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 50);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  // Close dropdown on route change
  useEffect(() => setIsDropdownOpen(false), [pathname]);

  return (
    <nav className={cn(
      "fixed top-0 left-0 w-full px-6 py-4 flex justify-between items-center z-[100] transition-all duration-500",
      isLightPage 
        ? "bg-white/80 backdrop-blur-md text-black border-b border-black/5" 
        : "mix-blend-difference text-white"
    )}>
      {/* LEFT: LOGO & LINKS */}
      <div className="flex items-center gap-10">
        <Link href="/" className="group">
          <h1 className="text-2xl font-black tracking-tighter uppercase">
            ORBIT<span className={isLightPage ? "text-neutral-400" : "text-neutral-500"}>.</span>
          </h1>
        </Link>

        <div className="hidden lg:flex items-center gap-8">
          {["Shop", "About", "Campaign"].map((item) => (
            <Link 
              key={item}
              href={item === "Shop" ? "/shop" : `/${item.toLowerCase()}`} 
              className="text-[10px] font-bold uppercase tracking-[0.2em] hover:opacity-50 transition-opacity"
            >
              {item}
            </Link>
          ))}
        </div>
      </div>

      {/* RIGHT: UTILITIES */}
      <div className="flex items-center gap-6">
        {/* CART TRIGGER */}
        <button onClick={openCart} className="relative group transition-transform active:scale-90">
          <ShoppingBag size={20} strokeWidth={2} />
          {cart.length > 0 && (
            <span className="absolute -top-2 -right-2 flex h-4 w-4 items-center justify-center rounded-full bg-red-500 text-[8px] font-bold text-white shadow-lg">
              {cart.length}
            </span>
          )}
        </button>

        {/* AUTH LOGIC */}
        <div className={cn(
          "flex items-center border-l pl-6 transition-colors",
          isLightPage ? "border-black/10" : "border-white/20"
        )}>
          {session ? (
            <div className="relative">
              <button 
                onClick={() => setIsDropdownOpen(!isDropdownOpen)}
                className="flex items-center gap-2 group"
              >
                <div className={cn(
                  "flex h-8 w-8 items-center justify-center border rounded-full transition-all",
                  isLightPage ? "border-black/20 group-hover:bg-black group-hover:text-white" : "border-white/20 group-hover:bg-white group-hover:text-black"
                )}>
                  <User size={14} />
                </div>
                <ChevronDown size={10} className={cn("transition-transform duration-300", isDropdownOpen && "rotate-180")} />
              </button>

              {isDropdownOpen && (
                <div className={cn(
                  "absolute right-0 mt-4 w-52 p-2 border shadow-2xl animate-in fade-in zoom-in-95 slide-in-from-top-2",
                  isLightPage ? "bg-white border-black/10 text-black" : "bg-neutral-900 border-white/10 text-white"
                )}>
                  <p className="px-4 py-2 text-[8px] font-mono text-neutral-500 uppercase tracking-widest border-b border-white/5 mb-1">
                    Verified Agent: {session.user?.name?.split(' ')[0]}
                  </p>
                  <Link href="/dashboard" className="flex items-center gap-3 px-4 py-3 text-[10px] font-bold uppercase tracking-widest hover:bg-white/5 transition-colors">
                    <LayoutDashboard size={14} /> Dashboard
                  </Link>
                  {session.user?.role === "ADMIN" && (
                    <Link href="/admin" className="flex items-center gap-3 px-4 py-3 text-[10px] font-bold uppercase tracking-widest text-purple-400 hover:bg-white/5 transition-colors">
                      Admin Panel
                    </Link>
                  )}
                  <button 
                    onClick={() => signOut({ callbackUrl: "/" })}
                    className="w-full flex items-center gap-3 px-4 py-3 text-[10px] font-bold uppercase tracking-widest text-red-500 hover:bg-red-500/5 transition-colors border-t border-white/5 mt-1"
                  >
                    <LogOut size={14} /> Sign Out
                  </button>
                </div>
              )}
            </div>
          ) : (
            <Link href="/auth/login" className="text-[10px] font-black uppercase tracking-widest hover:opacity-50 transition-opacity">
              Login
            </Link>
          )}
        </div>
      </div>
    </nav>
  );
}