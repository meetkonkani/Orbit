"use client";

import { useRef, useEffect, useMemo } from "react";
import { Canvas, useFrame } from "@react-three/fiber";
import * as THREE from "three";

function OptimizedParticles() {
  const pointsRef = useRef<THREE.Points>(null);
  const scrollRef = useRef(0);

  // 1. MOBILE OPTIMIZATION
  // Check if window exists (SSR safety) and if width is less than 768px
  const isMobile = typeof window !== 'undefined' && window.innerWidth < 768;
  
  // Mobile gets 600 particles (Save Battery), Desktop gets 1500 (Max Detail)
  const count = isMobile ? 600 : 1500;

  // 2. MEMOIZED MATH (The Fix)
  // We calculate positions ONLY when 'count' changes.
  const geometry = useMemo(() => {
    const positions = new Float32Array(count * 3);

    for (let i = 0; i < count; i++) {
      const theta = 2 * Math.PI * Math.random();
      const phi = Math.acos(2 * Math.random() - 1);
      const r = 1.2;

      positions[i * 3] = r * Math.sin(phi) * Math.cos(theta);
      positions[i * 3 + 1] = r * Math.sin(phi) * Math.sin(theta);
      positions[i * 3 + 2] = r * Math.cos(phi);
    }

    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    return geo;
  }, [count]);

  useEffect(() => {
    // Scroll Logic
    let totalHeight = document.documentElement.scrollHeight - window.innerHeight;
    
    const handleResize = () => {
      totalHeight = document.documentElement.scrollHeight - window.innerHeight;
    };

    const handleScroll = () => {
      scrollRef.current = window.scrollY / totalHeight;
    };

    window.addEventListener("scroll", handleScroll, { passive: true });
    window.addEventListener("resize", handleResize);

    return () => {
      window.removeEventListener("scroll", handleScroll);
      window.removeEventListener("resize", handleResize);
    };
  }, []);

useFrame((state, delta) => {
  if (!pointsRef.current) return;
  const scrollY = scrollRef.current; 

    pointsRef.current.rotation.y += delta * 0.02;
    pointsRef.current.rotation.x = scrollY * Math.PI; 
    pointsRef.current.rotation.z = scrollY * 0.3;
    
 const scale = 0.7 + scrollY * 0.2; 
  pointsRef.current.scale.setScalar(scale);
  });

  return (
    <points ref={pointsRef} geometry={geometry}>
     <pointsMaterial
  color="#ffffff"
  size={isMobile ? 0.025 : 0.012} 
  sizeAttenuation={true}
  transparent={true} 
  opacity={0.4} // Lower opacity makes the sphere feel deeper and more volumetric
  blending={THREE.AdditiveBlending} // This makes the points "glow" when they overlap
/>
    </points>
  );
}

export default function ParticleSphere() {
  return (
    <div className="fixed inset-0 z-0 h-full w-full pointer-events-none">
      <Canvas 
        camera={{ position: [0, 0, 3] }} 
        dpr={[1, 2]} // Support high-res screens (Retina) up to 2x
        gl={{ 
          antialias: false,
          powerPreference: "high-performance",
          alpha: true 
        }}
      >
        <OptimizedParticles />
      </Canvas>
    </div>
  );
}