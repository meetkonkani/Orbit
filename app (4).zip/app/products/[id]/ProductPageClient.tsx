"use client";

import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { toast } from "sonner";
import { useCart } from "@/app/context/CartContext";
import { 
  ArrowLeft, Share2, ShieldCheck, Truck, RotateCcw, 
  X, Maximize2, Ruler, MapPin, Loader2, CheckCircle2, Flame 
} from "lucide-react";
import { useRouter } from "next/navigation";
import Image from "next/image";
import Link from "next/link";

export default function ProductPageClient({ product, relatedProducts }: any) {
  const router = useRouter();
  const { addToCart } = useCart();

  // --- UI STATES ---
  const [size, setSize] = useState("M");
  const [activeImg, setActiveImg] = useState(0);
  const [isZoomed, setIsZoomed] = useState(false);
  const [isSizeGuideOpen, setIsSizeGuideOpen] = useState(false);

  // --- DELIVERY STATES ---
  const [pincode, setPincode] = useState("");
  const [isChecking, setIsChecking] = useState(false);
  const [deliveryDate, setDeliveryDate] = useState<string | null>(null);

  // --- DYNAMIC STOCK LOGIC ---
  const stockCount = product.stock ?? 0;
  const isLowStock = stockCount > 0 && stockCount <= 10;

  const images = Array.isArray(product.images) && product.images.length > 0 
    ? product.images : ["/fallback.jpg"];

  // Prevent background scroll when modals are open
  useEffect(() => {
    if (isZoomed || isSizeGuideOpen) document.body.style.overflow = "hidden";
    else document.body.style.overflow = "unset";
  }, [isZoomed, isSizeGuideOpen]);

  const handleCheckDelivery = async () => {
    if (pincode.length < 6) return toast.error("Enter a 6-digit pincode");
    setIsChecking(true);
    await new Promise(r => setTimeout(r, 1200)); // Simulate API
    const date = new Date();
    date.setDate(date.getDate() + 4);
    setDeliveryDate(`Estimated delivery by ${date.toLocaleDateString('en-IN', { day: 'numeric', month: 'short' })}`);
    setIsChecking(false);
  };

  return (
    <main className="min-h-screen bg-[#050505] text-white selection:bg-white selection:text-black">
      
      {/* 1. ZOOM OVERLAY */}
      <AnimatePresence>
        {isZoomed && (
          <motion.div 
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 z-[200] bg-black/95 flex items-center justify-center cursor-zoom-out"
            onClick={() => setIsZoomed(false)}
          >
            <X className="absolute top-10 right-10 text-white/40 hover:text-white" size={32} />
            <motion.div initial={{ scale: 0.9 }} animate={{ scale: 1 }} className="relative w-[90vw] h-[90vh]">
              <Image src={images[activeImg]} alt="Zoomed" fill className="object-contain" quality={100} />
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* 2. SIZE GUIDE DRAWER */}
      <AnimatePresence>
        {isSizeGuideOpen && (
          <>
            <motion.div 
              initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              onClick={() => setIsSizeGuideOpen(false)}
              className="fixed inset-0 bg-black/80 backdrop-blur-md z-[110]"
            />
            <motion.div 
              initial={{ x: "100%" }} animate={{ x: 0 }} exit={{ x: "100%" }}
              transition={{ type: "spring", damping: 25, stiffness: 200 }}
              className="fixed right-0 top-0 h-full w-full max-w-md bg-[#0a0a0a] z-[120] border-l border-white/10 p-10 shadow-2xl"
            >
              <div className="flex justify-between items-center mb-10">
                <h2 className="text-2xl font-black italic uppercase">Size Guide</h2>
                <X className="cursor-pointer hover:rotate-90 transition-transform" onClick={() => setIsSizeGuideOpen(false)} />
              </div>
              <div className="space-y-6">
                <p className="text-sm text-neutral-400">Measurements are in inches. Designed for an oversized fit.</p>
                <table className="w-full text-left">
                  <thead className="text-[10px] text-neutral-500 border-b border-white/10 uppercase tracking-widest">
                    <tr><th className="py-4">Size</th><th className="py-4">Chest</th><th className="py-4">Length</th></tr>
                  </thead>
                  <tbody className="text-sm border-b border-white/10">
                    <tr><td className="py-4 font-bold">S</td><td className="py-4">44"</td><td className="py-4">26"</td></tr>
                    <tr className="text-white bg-white/5"><td className="py-4 px-2 font-bold">M</td><td className="py-4 px-2">46"</td><td className="py-4 px-2">27"</td></tr>
                    <tr><td className="py-4 font-bold">L</td><td className="py-4">48"</td><td className="py-4">28"</td></tr>
                  </tbody>
                </table>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* 3. MAIN PAGE LAYOUT */}
      <div className="flex flex-col lg:flex-row min-h-screen">
        
        {/* LEFT: STICKY IMAGES */}
        <div className="w-full lg:w-3/5 bg-[#0a0a0a] relative lg:sticky lg:top-0 lg:h-screen flex items-center justify-center border-r border-white/5">
          <button onClick={() => router.back()} className="absolute top-8 left-8 z-30 flex items-center gap-2 text-[10px] font-bold uppercase tracking-widest hover:text-neutral-400 transition-colors">
            <ArrowLeft size={14} /> Back
          </button>

          <div className="relative w-full h-[55vh] lg:h-[75vh] cursor-zoom-in group" onClick={() => setIsZoomed(true)}>
             <div className="absolute inset-0 z-10 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                <div className="bg-white/10 backdrop-blur-xl p-4 rounded-full border border-white/20"><Maximize2 size={20} /></div>
            </div>
            <Image src={images[activeImg]} alt={product.title} fill priority className="object-contain p-12 transition-transform duration-700 group-hover:scale-105" />
          </div>

          <div className="absolute bottom-10 flex gap-3 z-20">
            {images.map((img: string, idx: number) => (
              <button key={idx} onClick={() => setActiveImg(idx)} className={`w-14 h-14 border-2 transition-all ${activeImg === idx ? "border-white opacity-100" : "border-transparent opacity-30 hover:opacity-100"}`}>
                <Image src={img} alt="thumb" width={56} height={56} className="object-cover h-full w-full" />
              </button>
            ))}
          </div>
        </div>

        {/* RIGHT: CONTENT DETAILS */}
        <div className="w-full lg:w-2/5 p-8 lg:p-16 xl:p-20 overflow-y-auto">
          
          <div className="flex justify-between items-start mb-4">
            <span className="text-[11px] font-bold text-neutral-500 uppercase tracking-[0.3em]">{product.category}</span>
            <Share2 className="text-neutral-500 cursor-pointer hover:text-white" size={18} />
          </div>

          <h1 className="text-6xl lg:text-7xl font-black italic uppercase leading-[0.85] mb-6 tracking-tighter">{product.title}</h1>
          
          <div className="flex items-center gap-6 mb-10">
            <p className="text-3xl font-light">₹{product.price.toLocaleString("en-IN")}</p>
            {isLowStock && (
              <div className="flex items-center gap-2 bg-orange-500/10 border border-orange-500/20 px-3 py-1 rounded-full">
                <motion.div animate={{ scale: [1, 1.2, 1] }} transition={{ repeat: Infinity, duration: 2 }}><Flame size={12} className="text-orange-500 fill-orange-500" /></motion.div>
                <span className="text-[10px] font-black uppercase text-orange-500">Only {stockCount} Left</span>
              </div>
            )}
          </div>

          {/* SIZE PICKER */}
          <div className="mb-10">
            <div className="flex justify-between mb-4 text-[11px] font-bold uppercase tracking-widest text-neutral-400">
              <span>Select Size</span>
              <button onClick={() => setIsSizeGuideOpen(true)} className="text-white underline underline-offset-8">Size Guide</button>
            </div>
            <div className="grid grid-cols-4 gap-2">
              {["S", "M", "L", "XL"].map((s) => (
                <button key={s} onClick={() => setSize(s)} className={`border py-4 text-xs font-black transition-all ${size === s ? "bg-white text-black border-white" : "border-white/10 text-neutral-500 hover:border-white/40"}`}>{s}</button>
              ))}
            </div>
          </div>

          <button
            onClick={() => { addToCart({...product, size, image: images[activeImg]}); toast.success("Added to Bag"); }}
            disabled={stockCount === 0}
            className="w-full py-6 bg-white text-black font-black uppercase tracking-[0.2em] hover:bg-neutral-200 transition-colors disabled:bg-neutral-900 disabled:text-neutral-700 mb-12"
          >
            {stockCount > 0 ? "Add To Cart" : "Sold Out"}
          </button>

          {/* PINCODE CHECKER */}
          <div className="bg-[#0f0f0f] border border-white/5 p-6 mb-12 rounded-sm">
            <div className="flex items-center gap-2 mb-4 text-neutral-400 font-bold uppercase text-[10px] tracking-widest">
              <MapPin size={14} /> Check Delivery
            </div>
            <div className="flex gap-2">
              <input 
                type="text" maxLength={6} placeholder="Enter Pincode" value={pincode}
                onChange={(e) => setPincode(e.target.value.replace(/\D/g, ''))}
                className="bg-black border border-white/10 px-4 py-3 text-sm flex-1 outline-none focus:border-white/40 transition-all"
              />
              <button onClick={handleCheckDelivery} disabled={isChecking || pincode.length < 6} className="bg-white/10 hover:bg-white/20 px-6 font-bold uppercase text-[10px] tracking-widest transition-all">
                {isChecking ? <Loader2 className="animate-spin" size={16} /> : "Check"}
              </button>
            </div>
            <AnimatePresence>
              {deliveryDate && (
                <motion.div initial={{ opacity: 0, y: -5 }} animate={{ opacity: 1, y: 0 }} className="mt-4 flex items-center gap-2 text-green-400 text-[11px] font-bold uppercase tracking-tight">
                  <CheckCircle2 size={14} /> {deliveryDate}
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* BRAND BENEFITS */}
          <div className="space-y-6 py-8 border-y border-white/5 mb-16">
            <div className="flex items-center gap-4 text-neutral-300">
              <Truck size={20} className="text-neutral-600" />
              <p className="text-[11px] font-bold uppercase tracking-widest">Complimentary Express Shipping</p>
            </div>
            <div className="flex items-center gap-4 text-neutral-300">
              <RotateCcw size={20} className="text-neutral-600" />
              <p className="text-[11px] font-bold uppercase tracking-widest">7-Day Premium Returns</p>
            </div>
            <div className="flex items-center gap-4 text-neutral-300">
              <ShieldCheck size={20} className="text-neutral-600" />
              <p className="text-[11px] font-bold uppercase tracking-widest">100% Verified Authentic</p>
            </div>
          </div>
        </div>
      </div>
    </main>
  );
}