"use server";

import { prisma } from "@/app/lib/prisma";
import { auth } from "@/app/auth";
import Razorpay from "razorpay";
import { nanoid } from "nanoid";
import type { CartItem } from "@/app/context/CartContext";

const razorpay = new Razorpay({
  key_id: process.env.RAZORPAY_KEY_ID!,
  key_secret: process.env.RAZORPAY_KEY_SECRET!,
});

export async function initiatePayment(total: number) {
  try {
    const order = await razorpay.orders.create({
      amount: Math.round(total * 100),
      currency: "INR",
      receipt: `rcpt_${nanoid(10)}`,
    });

    return { orderId: order.id, amount: order.amount };
  } catch (err) {
    console.error("RAZORPAY_INIT_ERROR", err);
    return { error: "PAYMENT_INIT_FAILED" };
  }
}

export async function createOrder(
  cart: CartItem[],
  total: number,
  shipping: {
    name: string;
    address: string;
    city: string;
    pincode: string;
    phone: string;
  },
  paymentMethod: "RAZORPAY" | "COD",
  paymentId?: string
) {
  const session = await auth();
  if (!session?.user?.email) return { error: "AUTH_REQUIRED" };

  const user = await prisma.user.findUnique({
    where: { email: session.user.email },
  });
  if (!user) return { error: "USER_NOT_FOUND" };

  const order = await prisma.order.create({
    data: {
      userId: user.id,
      total,
      status: paymentMethod === "COD" ? "PENDING" : "PAID",
      paymentMethod,
      paymentId: paymentId ?? null,

      shippingName: shipping.name,
      shippingPhone: shipping.phone,
      shippingAddress: shipping.address,
      shippingCity: shipping.city,
      shippingPincode: shipping.pincode,

      items: {
        create: cart.map((i) => ({
          productId: String(i.id),
          title: i.title,
          price: i.price,
          size: i.size,
          quantity: i.quantity,
          image: i.image,
        })),
      },
    },
  });

  return { success: true, orderId: order.id };
}
